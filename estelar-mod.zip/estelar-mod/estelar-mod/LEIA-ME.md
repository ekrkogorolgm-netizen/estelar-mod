# 🚀 Estelar — mod de foguetes, planetas e luas

Mod **Fabric** para **Minecraft Java 1.21.1**. Construa foguetes, vista o traje espacial e viaje para
a **Lua**, **Marte**, **Fobos**, **Vênus** e **Europa** — cada mundo tem terreno, blocos, céu e gravidade próprios.

---

## O que tem no mod

**Lugares para visitar**

| Destino | Gravidade | Foguete | Como é |
|---|---|---|---|
| 🌙 Lua | 0,17g | Nível I | Planícies cinzentas cheias de crateras. A **Terra fica parada no céu** preto e estrelado. Tem minério de titânio. |
| 🔴 Marte | 0,38g | Nível II | Desertos vermelhos, montanhas, vales enormes e cavernas. Céu cor de caramelo. Tem cristal marciano. |
| 🪨 Fobos | 0,06g | Nível II | Lua minúscula e esburacada — dá pra pular altíssimo! **Marte gigante no céu.** |
| 🟡 Vênus | 0,90g | Nível III | Montanhas extremas, mares de lava e névoa amarela grossa. Muito ouro e diamante. |
| 🧊 Europa | 0,13g | Nível III | Oceano congelado com icebergs e cristas de gelo, água escondida embaixo. **Júpiter enorme no céu.** |

**Coisas novas**
- 3 foguetes (Nível I, II e III) com contagem regressiva, fogo, fumaça, tremedeira e pouso suave
- Painel de navegação para escolher o destino
- Traje espacial (capacete, traje, calças e botas) — sem ele o oxigênio acaba fora da Terra
- Galão de combustível, motor de foguete, titânio, cristal marciano
- 11 blocos novos (regolito lunar, rochas de cada planeta, gelo de Europa, minérios...)
- Gravidade baixa de verdade: você pula mais alto e cai devagar (e se machuca menos)

---

## Como jogar (passo a passo)

1. **Faça o traje espacial** (lã branca + ferro + vidro) e vista as **4 peças**.
2. **Faça um Motor de Foguete** e depois um **Foguete Nível I**.
3. **Faça Galões de Combustível** (ferro + carvão + redstone).
4. **Coloque o foguete no chão** (botão direito num bloco).
5. **Abasteça**: clique com o botão direito no foguete segurando galões. Cada galão = 25 de combustível.
6. **Entre** (botão direito com a mão vazia) e aperte **ESPAÇO** para abrir o painel.
7. Escolha **Lua**. Contagem regressiva... **DECOLAGEM!** 🚀
8. Na Lua, minere **titânio** para fazer o **Foguete Nível II** (Marte e Fobos).
9. Em Marte, minere **cristal marciano** (picareta de ferro) para o **Foguete Nível III** (Vênus e Europa).

> ⚠ **Leve combustível para voltar!** O foguete fica onde pousou. Para voltar, entre nele, abasteça e escolha **Terra**.
> Para sair do foguete: **Shift**. Para desmontar e guardar o foguete: bata nele **3 vezes**.

**Combustível por viagem:** Lua 50 · Marte/Fobos 75 · Vênus/Europa 100
**Tanque:** Nível I = 100 · Nível II = 150 · Nível III = 200

---

## Receitas

```
Motor de Foguete        Foguete Nível I         Foguete Nível II        Foguete Nível III
 F  P  F                 .  R  .                 .  T  .                 .  C  .
 F  Fo F                 F  V  F                 T  F1 T                 C  F2 C
 F  .  F                 F  M  F                 T  M  T                 D  M  D

F = lingote de ferro   P = pólvora   Fo = fornalha   R = redstone   V = painel de vidro
M = motor de foguete   T = lingote de titânio   F1/F2 = foguete anterior   C = cristal marciano   D = diamante

Galão de Combustível (x2, sem forma): ferro + carvão + carvão + redstone
Galão de Combustível (x3, sem forma): ferro + pó de blaze

Capacete     Traje         Calças        Botas
 L  F  L      L  .  L       L  L  L       L  .  L
 L  V  L      F  G  F       L  .  L       F  .  F
              L  L  L       F  .  F
L = lã branca   F = lingote de ferro   V = vidro   G = frasco de vidro
```
Titânio bruto → fornalha → lingote de titânio. 9 lingotes = bloco de titânio.
Tudo também aparece no **livro de receitas** e na aba criativa **Estelar**.

---

## Como transformar o projeto no arquivo `.jar` do mod

O mod vem como **código-fonte**. Você precisa compilar uma vez para gerar o `.jar`. Escolha um jeito:

### Jeito 1 — No seu computador (Windows)
1. Instale o **Java 21** (JDK): https://adoptium.net → "Temurin 21 (LTS)" → instale com tudo marcado.
2. Descompacte o `estelar-mod.zip` numa pasta (ex.: `C:\estelar-mod`).
3. Abra a pasta, clique na barra de endereço, digite `cmd` e aperte Enter.
4. Digite:
   ```
   gradlew.bat build
   ```
   A primeira vez demora (5–15 min), porque baixa o Minecraft e as ferramentas.
5. Quando aparecer **BUILD SUCCESSFUL**, o mod estará em `build\libs\estelar-1.0.0.jar`.

No Mac/Linux é igual, mas o comando é `./gradlew build`.

### Jeito 2 — Pela internet com GitHub (sem instalar nada)
1. Crie uma conta em https://github.com e um repositório novo.
2. Envie todos os arquivos do projeto (botão "Add file" → "Upload files"), incluindo a pasta `.github`.
3. Vá na aba **Actions**, espere o "build" ficar verde ✅, clique nele e baixe **estelar-mod** em "Artifacts".

---

## Como instalar no Minecraft
1. Instale o **Fabric Loader** para **1.21.1**: https://fabricmc.net/use/installer/
2. Baixe o **Fabric API** para 1.21.1: https://modrinth.com/mod/fabric-api
3. Coloque `estelar-1.0.0.jar` e o Fabric API na pasta `.minecraft/mods`
   (Windows: aperte `Win+R`, digite `%appdata%\.minecraft` e Enter).
4. Abra o launcher, escolha o perfil **fabric-loader-1.21.1** e jogue!

Dica: os planetas funcionam em mundos novos e também nos que você já tem.

---

## Se der algum problema
- **Erro ao compilar:** copie as linhas vermelhas que aparecem e mande para quem te ajuda (ou para o Claude) — dá pra corrigir rapidinho.
- **"Incompatible mods"**: confira se o Minecraft é 1.21.1 e se o Fabric API está na pasta mods.
- **Fiquei sem ar:** você precisa das 4 peças do traje vestidas ao mesmo tempo.

## Para quem quiser mexer no mod
- Código Java: `src/main` (lógica) e `src/client` (gráficos, céu, painel).
- Texturas e mundos são gerados pelos scripts em `tools/` (`python3 tools/gen_textures.py` e `python3 tools/gen_data.py`).
