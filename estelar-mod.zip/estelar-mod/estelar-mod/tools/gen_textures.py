"""Gera todas as texturas do mod Estelar (pixel art procedural + desenhos ASCII).

Uso:  python3 tools/gen_textures.py
"""
import math
import os
import random

import numpy as np
from PIL import Image

from rocket_parts import PARTS, TEX_W, TEX_H, pack

ROOT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "estelar", "textures")


def hexc(s, a=255):
    s = s.lstrip("#")
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), a)


def save(img, *path):
    full = os.path.join(ROOT, *path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    img.save(full)


# ----------------------------------------------------------------- ruído

def tile_noise(size, seed, octaves=((4, 1.0), (8, 0.5), (16, 0.25))):
    """Ruído suave que repete nas bordas (textura de bloco sem emenda)."""
    rng = np.random.default_rng(seed)
    out = np.zeros((size, size))
    for cells, amp in octaves:
        grid = rng.random((cells, cells))
        ys, xs = np.mgrid[0:size, 0:size] / size * cells
        x0 = np.floor(xs).astype(int)
        y0 = np.floor(ys).astype(int)
        fx = xs - x0
        fy = ys - y0
        fx = fx * fx * (3 - 2 * fx)
        fy = fy * fy * (3 - 2 * fy)
        x1 = (x0 + 1) % cells
        y1 = (y0 + 1) % cells
        x0 %= cells
        y0 %= cells
        a = grid[y0, x0] * (1 - fx) + grid[y0, x1] * fx
        b = grid[y1, x0] * (1 - fx) + grid[y1, x1] * fx
        out += (a * (1 - fy) + b * fy) * amp
    out -= out.min()
    out /= max(out.max(), 1e-9)
    return out


def palette_block(palette, seed, grain=0.35):
    """Bloco 16x16: ruído suave + granulado mapeado numa paleta (escura → clara)."""
    rng = random.Random(seed)
    n = tile_noise(16, seed)
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for y in range(16):
        for x in range(16):
            v = n[y, x] + (rng.random() - 0.5) * grain
            v = min(max(v, 0.0), 0.999)
            px[x, y] = hexc(palette[int(v * len(palette))])
    return img


def speckle(img, colors, count, seed):
    rng = random.Random(seed)
    px = img.load()
    for _ in range(count):
        px[rng.randrange(16), rng.randrange(16)] = hexc(rng.choice(colors))
    return img


def pits(img, dark, light, count, seed):
    """Pequenas crateras: pixel escuro com brilho embaixo à direita."""
    rng = random.Random(seed)
    px = img.load()
    for _ in range(count):
        x, y = rng.randrange(16), rng.randrange(16)
        px[x, y] = hexc(dark)
        px[(x + 1) % 16, y] = hexc(dark)
        px[x, (y + 1) % 16] = hexc(light)
        px[(x + 1) % 16, (y + 1) % 16] = hexc(light)
    return img


def cracks(img, color, count, length, seed, glow=None):
    rng = random.Random(seed)
    px = img.load()
    for _ in range(count):
        x, y = rng.randrange(16), rng.randrange(16)
        for _ in range(length):
            px[x % 16, y % 16] = hexc(color)
            if glow and rng.random() < 0.35:
                px[(x + 1) % 16, y % 16] = hexc(glow)
            step = rng.choice([(1, 0), (1, 1), (0, 1), (1, -1)])
            x += step[0]
            y += step[1]
    return img


def lineae(img, color, halo, seed):
    """Riscos avermelhados de Europa: duas linhas diagonais finas que cruzam a textura."""
    rng = random.Random(seed)
    px = img.load()
    for offset, slope in ((rng.randrange(16), 1), (rng.randrange(16), -1)):
        for x in range(16):
            y = (offset + slope * x + (1 if rng.random() < 0.2 else 0)) % 16
            px[x, y] = hexc(color)
            if rng.random() < 0.5:
                px[x, (y + 1) % 16] = hexc(halo)
    return img


def ore_blobs(img, shades, count, seed, outline):
    """Manchas de minério: 2-4 pixels com sombreamento e contorno escuro."""
    rng = random.Random(seed)
    px = img.load()
    spots = []
    attempts = 0
    while len(spots) < count and attempts < 200:
        attempts += 1
        x, y = rng.randrange(1, 14), rng.randrange(1, 14)
        if all(abs(x - sx) > 3 or abs(y - sy) > 3 for sx, sy in spots):
            spots.append((x, y))
    for x, y in spots:
        shape = [(0, 0), (1, 0), (0, 1), (1, 1)]
        if rng.random() < 0.5:
            shape.append((2, rng.randrange(2)))
        for dx, dy in shape:
            for ox, oy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                p = (x + dx + ox, y + dy + oy)
                if (p[0] - x, p[1] - y) not in shape and 0 <= p[0] < 16 and 0 <= p[1] < 16:
                    px[p] = hexc(outline)
        for dx, dy in shape:
            light = shades[0] if (dx, dy) == (0, 0) else shades[2] if dy == 1 and dx >= 1 else shades[1]
            px[x + dx, y + dy] = hexc(light)
    return img


def strata(img, color, rows, seed):
    rng = random.Random(seed)
    px = img.load()
    for row in rows:
        for x in range(16):
            y = row + (1 if rng.random() < 0.25 else 0)
            if rng.random() < 0.85:
                px[x, y % 16] = hexc(color)
    return img


# ---------------------------------------------------------------- blocos

def make_blocks():
    b = {}
    regolith = palette_block(["8b8b8d", "999a9c", "a6a7a9", "b3b4b6", "c1c2c4"], 11)
    pits(regolith, "7b7c7e", "cfd0d2", 3, 12)
    speckle(regolith, ["d8d8da", "6f7072"], 6, 13)
    b["moon_regolith"] = regolith

    moon_rock = palette_block(["5a5b5f", "65666a", "707175", "7b7c80", "86878b"], 21)
    cracks(moon_rock, "4a4b4f", 2, 6, 22)
    speckle(moon_rock, ["95969a"], 5, 23)
    b["moon_rock"] = moon_rock

    ore = moon_rock.copy()
    ore_blobs(ore, ["eef4fb", "b9c8da", "8297b1"], 4, 31, "3e4148")
    b["moon_titanium_ore"] = ore

    mars_sand = palette_block(["9e3d17", "ad4619", "bc5020", "c85d29", "d46c35", "de7c45"], 41, grain=0.45)
    speckle(mars_sand, ["7f2f12", "e8935f"], 8, 42)
    b["mars_sand"] = mars_sand

    mars_rock = palette_block(["5e2616", "6b2d1b", "783521", "853e27", "92482e"], 51)
    strata(mars_rock, "52200f", [3, 9, 14], 52)
    speckle(mars_rock, ["a2573a"], 6, 53)
    b["mars_rock"] = mars_rock

    crystal = mars_rock.copy()
    ore_blobs(crystal, ["ffd1dc", "ff5c82", "c4224d"], 4, 61, "3a0f0a")
    b["mars_crystal_ore"] = crystal

    phobos = palette_block(["3a332e", "443c36", "4e4640", "58504a", "635a53"], 71)
    pits(phobos, "2c2622", "6f665e", 5, 72)
    b["phobos_rock"] = phobos

    venus = palette_block(["6a5230", "785e37", "876b3e", "967846", "a5864f"], 81)
    cracks(venus, "3d2a14", 3, 6, 82, glow="ff8a2a")
    speckle(venus, ["ffb347"], 3, 83)
    b["venus_rock"] = venus

    ice = palette_block(["c7dce8", "d2e5ef", "dcecf4", "e6f2f8", "f0f8fb"], 91, grain=0.2)
    lineae(ice, "a0522d", "c48a6a", 94)
    speckle(ice, ["a9cde2", "ffffff"], 6, 94)
    b["europa_ice"] = ice

    europa_rock = palette_block(["2f3740", "38414b", "414b56", "4a5561", "535f6c"], 101)
    speckle(europa_rock, ["6a7a8c", "26303a"], 7, 102)
    b["europa_rock"] = europa_rock

    # Bloco de titânio: placa metálica com rebites
    ti = Image.new("RGBA", (16, 16))
    px = ti.load()
    for y in range(16):
        for x in range(16):
            v = 0.55 + 0.25 * (1 - (x + y) / 30)
            c = int(150 + 70 * v)
            px[x, y] = (c - 18, c - 6, c + 6, 255)
    for i in range(16):
        px[i, 0] = hexc("e9eef4")
        px[0, i] = hexc("e9eef4")
        px[i, 15] = hexc("6c7684")
        px[15, i] = hexc("6c7684")
    for i in range(2, 14):
        px[i, 7] = hexc("8e99a8")
        px[7, i] = hexc("8e99a8")
        px[i, 8] = hexc("d2dae3")
        px[8, i] = hexc("d2dae3")
    for cx, cy in ((2, 2), (13, 2), (2, 13), (13, 13)):
        px[cx, cy] = hexc("f5f8fb")
        px[cx + 1 if cx < 8 else cx - 1, cy] = hexc("7a8494")
    b["titanium_block"] = ti

    for name, img in b.items():
        save(img, "block", name + ".png")


# ----------------------------------------------------------------- itens

def ascii_image(rows, palette):
    assert len(rows) == 16, len(rows)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for y, row in enumerate(rows):
        assert len(row) == 16, (y, row, len(row))
        for x, ch in enumerate(row):
            if ch != ".":
                px[x, y] = hexc(palette[ch])
    return img


ROCKET_ICON = [
    ".......oo.......",
    "......oaao......",
    "......oaAo......",
    ".....oaaAAo.....",
    ".....owwwso.....",
    ".....owggso.....",
    ".....owgGso.....",
    ".....owwwso.....",
    ".....oaaAAo.....",
    ".....owwwso.....",
    "....oowwwsoo....",
    "...oaowwwsoAo...",
    "...oaowwwsoAo...",
    "...oooooooooo...",
    "......oyyo......",
    ".......ff.......",
]

ITEMS = {
    "fuel_canister": ([
        "................",
        "...........oo...",
        "..oooooooooyyo..",
        ".oRRRRRRRRoyo...",
        ".oRoooooRRRRo...",
        ".oRo...oRRRRo...",
        ".oRRoooRRRRRo...",
        ".oRRRRRRRRRRro..",
        ".oRYYYKYYYYRro..",
        ".oRYYYKKYYYRro..",
        ".oRYYKKKKYYRro..",
        ".oRYYKKKKYYRro..",
        ".oRYYYKKYYYRro..",
        ".oRRRRRRRRRRro..",
        "..ooooooooooo...",
        "................",
    ], {"o": "2a0d0d", "R": "d23a2a", "r": "9c2420", "y": "f2c230", "Y": "f6d24a", "K": "3a2a10"}),

    "raw_titanium": ([
        "................",
        "................",
        "................",
        "......ooo.......",
        "....oooLLoo.....",
        "...oLLLmmmLo....",
        "..oLLmmmmmmmo...",
        "..oLmmmmmdmmdo..",
        ".oLmmmdmmmmmmdo.",
        ".oLmmmmmmmdmmdo.",
        ".ommdmmmmmmmddo.",
        "..ommmmmdmmddo..",
        "...oodmmmmddoo..",
        ".....ooooooo....",
        "................",
        "................",
    ], {"o": "2e3440", "L": "e3ebf5", "m": "a9b8cb", "d": "6f8098"}),

    "titanium_ingot": ([
        "................",
        "................",
        "................",
        "................",
        "......oooooooo..",
        ".....oHHHHHHHso.",
        "....oHLLLLLLHsso",
        "...oHLLLLLLHssso",
        "..oooooooooosso.",
        "..oMMMMMMMMosso.",
        "..oMMMMMMMMoso..",
        "..oDDDDDDDDoo...",
        "..oooooooooo....",
        "................",
        "................",
        "................",
    ], {"o": "2b313b", "H": "f4f8fc", "L": "d3dde9", "s": "7f8ea3", "M": "aebccd", "D": "8a99ad"}),

    "mars_crystal": ([
        "................",
        "................",
        "......oooo......",
        ".....oLLppo.....",
        "....oLLpppPo....",
        "...oLLppppPPo...",
        "..oLpppppppPPo..",
        "..oppppppppPDo..",
        "...oppppppPDo...",
        "....oppppPDo....",
        ".....opppDo.....",
        "......opDo......",
        ".......oo.......",
        "................",
        "................",
        "................",
    ], {"o": "4a0718", "L": "ffd6e0", "p": "ff4f78", "P": "d42a55", "D": "8f1236"}),

    "rocket_engine": ([
        "................",
        "....oooooooo....",
        "....oMMMMMMo....",
        "....oMmmmmMo....",
        ".....oMMMMo.....",
        ".....oDDDDo.....",
        "....oDDDDDDo....",
        "...oDDDDDDDDo...",
        "..oDDDDDDDDDDo..",
        "..oooooooooooo..",
        "...yyyffffyyy...",
        "....yyffffyy....",
        ".....yyffyy.....",
        "......yffy......",
        ".......yy.......",
        "................",
    ], {"o": "1d1f24", "M": "b8c0cc", "m": "8a93a1", "D": "4b4f58", "y": "ffcf3a", "f": "ff7a1a"}),

    "space_helmet": ([
        "................",
        "................",
        ".....oooooo.....",
        "....owwwwwwo....",
        "...owwwwwwwso...",
        "..owwggggggwso..",
        "..owgbbbbbbgso..",
        "..owgbBbbbbgso..",
        "..owgbbbbbbgso..",
        "..owwggggggwso..",
        "..owwwwwwwwwso..",
        "..oaaaaaaaaaao..",
        "...oooooooooo...",
        "................",
        "................",
        "................",
    ], {"o": "1f2329", "w": "f2f4f7", "s": "b9c0ca", "g": "8d97a5", "b": "2a5fa8", "B": "9fd2ff", "a": "f07b1d"}),

    "space_chestplate": ([
        "................",
        "..oooo....oooo..",
        ".owwwwoooowwwwo.",
        ".owwwwwwwwwwwso.",
        ".owwswwwwwwswso.",
        ".ooowwaaaawwooo.",
        "...owwaRGawwo...",
        "...owwaaaawso...",
        "...owwwwwwwso...",
        "...oaaaaaaaao...",
        "...owwwwwwwso...",
        "...owwwwwwwso...",
        "...ooooooooo....",
        "................",
        "................",
        "................",
    ], {"o": "1f2329", "w": "f2f4f7", "s": "b9c0ca", "a": "f07b1d", "R": "ff3b3b", "G": "45e06a"}),

    "space_leggings": ([
        "................",
        "................",
        "...oooooooooo...",
        "...oaaaaaaaao...",
        "...owwwwwwwso...",
        "...owwsoowwso...",
        "...owwsoowwso...",
        "...owwsoowwso...",
        "...oaasooaaso...",
        "...owwsoowwso...",
        "...owwsoowwso...",
        "...owwsoowwso...",
        "...oooooooooo...",
        "................",
        "................",
        "................",
    ], {"o": "1f2329", "w": "f2f4f7", "s": "b9c0ca", "a": "f07b1d"}),

    "space_boots": ([
        "................",
        "................",
        "................",
        "................",
        "................",
        "................",
        "................",
        "................",
        "..oooo....oooo..",
        "..owso....owso..",
        "..owso....owso..",
        "..owwoo...owwoo.",
        "..owwwso..owwwso",
        "..aaaaao..aaaaao",
        "..ooooo...ooooo.",
        "................",
    ], {"o": "1f2329", "w": "f2f4f7", "s": "b9c0ca", "a": "f07b1d"}),
}

TIER_COLORS = {
    1: {"w": "eceff3", "s": "aab2bd", "a": "d6332a", "A": "8f1d17"},
    2: {"w": "eceff3", "s": "aab2bd", "a": "2f6fe0", "A": "173f8f"},
    3: {"w": "3a3d46", "s": "24262c", "a": "f0b429", "A": "a8770f"},
}


def make_items():
    for name, (rows, pal) in ITEMS.items():
        save(ascii_image(rows, pal), "item", name + ".png")
    for tier, colors in TIER_COLORS.items():
        pal = {"o": "15181d", "g": "4fa9e8", "G": "c8ecff", "y": "ffd23a", "f": "ff7a1a"}
        pal.update(colors)
        save(ascii_image(ROCKET_ICON, pal), "item", f"rocket_tier_{tier}.png")


# ------------------------------------------------------------- armadura

def fill(px, x, y, w, h, color):
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            px[xx, yy] = hexc(color) if isinstance(color, str) else color


def suit_base(px, x, y, w, h, seed):
    rng = random.Random(seed)
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            c = rng.choice(["eef1f5", "e6eaef", "f4f6f9"])
            px[xx, yy] = hexc(c)


def box_faces(u, v, w, h, d):
    """Regiões (x, y, w, h) das faces de uma caixa no layout do Minecraft."""
    return {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h),
        "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h),
        "back": (u + 2 * d + w, v + d, w, h),
    }


def make_armor():
    # Camada 1: capacete, peitoral, braços, botas
    l1 = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    px = l1.load()

    head = box_faces(0, 0, 8, 8, 8)
    for face, (x, y, w, h) in head.items():
        suit_base(px, x, y, w, h, sum(map(ord, face)))
    fx, fy, _, _ = head["front"]
    fill(px, fx, fy + 1, 8, 1, "c9d0d9")
    fill(px, fx + 1, fy + 2, 6, 4, "2a5fa8")      # viseira
    fill(px, fx + 1, fy + 2, 2, 1, "9fd2ff")      # reflexo
    fill(px, fx + 2, fy + 3, 1, 1, "9fd2ff")
    fill(px, fx, fy + 7, 8, 1, "f07b1d")          # anel laranja
    for side in ("right", "left"):
        x, y, w, h = head[side]
        fill(px, x + 2, y + 3, 4, 3, "b9c0ca")    # comunicador
        fill(px, x + 3, y + 4, 2, 1, "45e06a")
        fill(px, x, y + 7, w, 1, "f07b1d")
    x, y, w, h = head["back"]
    fill(px, x, y + 7, w, 1, "f07b1d")
    fill(px, x + 3, y + 2, 2, 3, "b9c0ca")

    body = box_faces(16, 16, 8, 12, 4)
    for face, (x, y, w, h) in body.items():
        suit_base(px, x, y, w, h, 200 + len(face))
    x, y, w, h = body["front"]
    fill(px, x + 2, y + 2, 4, 3, "b9c0ca")        # painel
    fill(px, x + 3, y + 3, 1, 1, "ff3b3b")
    fill(px, x + 4, y + 3, 1, 1, "45e06a")
    fill(px, x, y + 6, w, 1, "f07b1d")
    fill(px, x + 1, y + 9, 6, 1, "c9d0d9")
    x, y, w, h = body["back"]
    fill(px, x + 1, y + 1, 6, 9, "8d97a5")        # mochila de oxigênio
    fill(px, x + 2, y + 2, 2, 7, "c9d0d9")
    fill(px, x + 4, y + 2, 2, 7, "c9d0d9")
    fill(px, x + 2, y + 2, 1, 7, "eef1f5")
    fill(px, x + 4, y + 2, 1, 7, "eef1f5")

    arm = box_faces(40, 16, 4, 12, 4)
    for face, (x, y, w, h) in arm.items():
        suit_base(px, x, y, w, h, 300 + len(face))
        if face not in ("top", "bottom"):
            fill(px, x, y + 4, w, 1, "f07b1d")
            fill(px, x, y + 10, w, 2, "b9c0ca")   # luvas

    leg = box_faces(0, 16, 4, 12, 4)
    for face, (x, y, w, h) in leg.items():
        if face in ("top",):
            continue
        if face == "bottom":
            fill(px, x, y, w, h, "3b4048")
            continue
        fill(px, x, y + 7, w, 5, "eef1f5")        # botas
        fill(px, x, y + 7, w, 1, "f07b1d")
        fill(px, x, y + 11, w, 1, "3b4048")
    save(l1, "models", "armor", "space_suit_layer_1.png")

    # Camada 2: calças
    l2 = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    px = l2.load()
    for face, (x, y, w, h) in leg.items():
        suit_base(px, x, y, w, h, 400 + len(face))
        if face not in ("top", "bottom"):
            fill(px, x, y + 5, w, 2, "b9c0ca")    # joelheira
            fill(px, x, y + 1, w, 1, "f07b1d")
    for face, (x, y, w, h) in body.items():
        if face in ("top",):
            continue
        if face == "bottom":
            suit_base(px, x, y, w, h, 500)
            continue
        fill(px, x, y + h - 4, w, 4, "eef1f5")
        fill(px, x, y + h - 4, w, 1, "f07b1d")    # cinto
        fill(px, x, y + h - 3, w, 1, "8d97a5")
    save(l2, "models", "armor", "space_suit_layer_2.png")


# --------------------------------------------------------------- foguete

def make_rocket_textures():
    uv = pack()
    for tier, colors in TIER_COLORS.items():
        img = Image.new("RGBA", (TEX_W, TEX_H), (0, 0, 0, 0))
        px = img.load()
        body_c = hexc(colors["w"])
        shade_c = hexc(colors["s"])
        accent = hexc(colors["a"])
        accent_dark = hexc(colors["A"])
        rng = random.Random(tier)

        for name, x, y, z, w, h, d in PARTS:
            u, v = uv[name]
            faces = box_faces(u, v, w, h, d)

            def paint(region, base, edge=None, noise=0):
                rx, ry, rw, rh = region
                for yy in range(ry, ry + rh):
                    for xx in range(rx, rx + rw):
                        c = base
                        if noise:
                            k = rng.randint(-noise, noise)
                            c = (max(0, min(255, c[0] + k)), max(0, min(255, c[1] + k)), max(0, min(255, c[2] + k)), 255)
                        px[xx, yy] = c
                if edge:
                    for xx in range(rx, rx + rw):
                        px[xx, ry + rh - 1] = edge

            if name.startswith("body"):
                # As faixas usam a altura absoluta do modelo, para casar entre as duas caixas do casco.
                def row_of(model_y):
                    return model_y - y
                for face in ("right", "front", "left", "back"):
                    rx, ry, rw, rh = faces[face]
                    paint(faces[face], body_c, noise=4)
                    for yy in range(ry, ry + rh):
                        px[rx, yy] = shade_c
                        px[rx + rw - 1, yy] = shade_c
                    rows = {-50: accent, -49: accent, -48: accent_dark, -14: accent, -13: accent,
                            -38: shade_c, -24: shade_c}
                    for model_y, color in rows.items():
                        r = row_of(model_y)
                        if 0 <= r < rh:
                            for xx in range(rx, rx + rw):
                                px[xx, ry + r] = color
                    for model_y in (-37, -23):
                        r = row_of(model_y)
                        for xx in range(rx + 1, rx + rw - 1, 3):
                            px[xx, ry + r] = shade_c
                if name == "body_b":
                    # número do nível (I, II, III) nas laterais
                    for face in ("left", "right"):
                        rx, ry, rw, rh = faces[face]
                        start = rx + rw // 2 - (tier * 3 - 1) // 2
                        for i in range(tier):
                            for r in range(row_of(-34), row_of(-27)):
                                px[start + i * 3, ry + r] = accent_dark
                                px[start + i * 3 + 1, ry + r] = accent_dark
                paint(faces["top"], shade_c)
                paint(faces["bottom"], hexc("3a3d44"))
            elif name.startswith("nose") or name == "tip":
                base = hexc("c9d0da") if name == "tip" else accent
                for face, region in faces.items():
                    paint(region, base, noise=3)
                    if face in ("right", "front", "left", "back") and name != "tip":
                        rx, ry, rw, rh = region
                        for yy in range(ry, ry + rh):
                            px[rx, yy] = accent_dark
                        for xx in range(rx, rx + rw):
                            px[xx, ry + rh - 1] = accent_dark
            elif name.startswith("fin"):
                for face, region in faces.items():
                    paint(region, accent, noise=3)
                    rx, ry, rw, rh = region
                    if face in ("right", "front", "left", "back"):
                        for yy in range(ry, ry + rh):
                            px[rx, yy] = accent_dark
                        for xx in range(rx, rx + rw):
                            px[xx, ry] = accent_dark
                            px[xx, ry + rh - 1] = hexc("2b2d33")
            elif name.startswith("nozzle"):
                for face, region in faces.items():
                    rx, ry, rw, rh = region
                    for yy in range(ry, ry + rh):
                        for xx in range(rx, rx + rw):
                            t = (yy - ry) / max(rh - 1, 1)
                            c = int(70 - 25 * t)
                            px[xx, yy] = (c, c + 3, c + 8, 255)
                    if face in ("right", "front", "left", "back"):
                        for xx in range(rx, rx + rw):
                            px[xx, ry] = hexc("8a919c")
                rx, ry, rw, rh = faces["bottom"]
                for yy in range(ry, ry + rh):
                    for xx in range(rx, rx + rw):
                        dx = (xx - rx - rw / 2 + 0.5) / (rw / 2)
                        dy = (yy - ry - rh / 2 + 0.5) / (rh / 2)
                        r = math.sqrt(dx * dx + dy * dy)
                        px[xx, yy] = hexc("ff9a2a") if r < 0.45 else hexc("2a1a14") if r < 0.85 else hexc("4a4d55")
            elif name == "window":
                for face, region in faces.items():
                    paint(region, hexc("9aa3af"))
                rx, ry, rw, rh = faces["front"]
                paint((rx + 1, ry + 1, rw - 2, rh - 2), hexc("3b8fd4"))
                px[rx + 1, ry + 1] = hexc("d8f1ff")
                px[rx + 2, ry + 1] = hexc("d8f1ff")
                px[rx + 1, ry + 2] = hexc("d8f1ff")
                px[rx + rw - 2, ry + rh - 2] = hexc("1f5c8f")
        save(img, "entity", f"rocket_tier_{tier}.png")


# --------------------------------------------------------------- planetas

def value_noise_sphere(nx, ny, nz, seed, scale, octaves=4):
    """Ruído 3D barato (soma de senos) para desenhar continentes numa esfera."""
    rng = random.Random(seed)
    total = 0.0
    amp = 1.0
    norm = 0.0
    for o in range(octaves):
        f = scale * (2 ** o)
        ax, ay, az = rng.uniform(-1, 1), rng.uniform(-1, 1), rng.uniform(-1, 1)
        px_, py_, pz_ = rng.uniform(0, 6.28), rng.uniform(0, 6.28), rng.uniform(0, 6.28)
        total += amp * (math.sin(nx * f * (1 + ax) + py_ + math.sin(ny * f * 1.3 + pz_)) *
                        math.cos(ny * f * (1 + ay) + px_ + math.sin(nz * f * 0.7 + px_)) *
                        math.sin(nz * f * (1 + az) + pz_ + 1.7))
        norm += amp
        amp *= 0.5
    return total / norm


def planet(size, color_fn, light=(-0.6, -0.45, 0.66), atmosphere=None, terminator=0.08):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    px = img.load()
    r = size / 2 - 1.5
    c = size / 2 - 0.5
    lx, ly, lz = light
    ln = math.sqrt(lx * lx + ly * ly + lz * lz)
    lx, ly, lz = lx / ln, ly / ln, lz / ln
    for y in range(size):
        for x in range(size):
            dx = (x - c) / r
            dy = (y - c) / r
            d2 = dx * dx + dy * dy
            if d2 > 1.0:
                if atmosphere and d2 < 1.12:
                    a = int(120 * (1 - (d2 - 1.0) / 0.12))
                    px[x, y] = atmosphere[:3] + (a,)
                continue
            nz = math.sqrt(1 - d2)
            base = color_fn(dx, dy, nz)
            shade = dx * lx + dy * ly + nz * lz
            k = max(0.0, min(1.0, (shade + terminator) / (1 + terminator)))
            k = 0.12 + 0.88 * k ** 0.8
            col = tuple(int(min(255, ch * k)) for ch in base[:3])
            if atmosphere:
                rim = (1 - nz) ** 3
                col = tuple(int(col[i] * (1 - rim * 0.6) + atmosphere[i] * rim * 0.6 * max(k, 0.3)) for i in range(3))
            edge_alpha = 255 if d2 < 0.94 else int(255 * (1 - (d2 - 0.94) / 0.06 * 0.5))
            px[x, y] = col + (edge_alpha,)
    return img


def make_planets():
    def earth(x, y, z):
        n = value_noise_sphere(x, y, z, 5, 3.2)
        cloud = value_noise_sphere(x, y, z, 9, 5.0)
        if abs(y) > 0.86:
            base = hexc("f2f6fa")
        elif n > 0.12:
            base = hexc("4f8f3a") if n < 0.3 else hexc("8b7a4a")
        else:
            base = hexc("1f5fbf") if n < -0.05 else hexc("2f78d6")
        if cloud > 0.32:
            base = hexc("f4f7fb")
        return base

    def moon(x, y, z):
        n = value_noise_sphere(x, y, z, 15, 2.5)
        base = hexc("6f7072") if n > 0.18 else hexc("b5b6b8")
        crater = value_noise_sphere(x, y, z, 16, 9.0)
        if crater > 0.55:
            base = hexc("8d8e90")
        return base

    def mars(x, y, z):
        n = value_noise_sphere(x, y, z, 25, 2.8)
        if y < -0.85:
            return hexc("f1e9e2")
        if n > 0.2:
            return hexc("7a2f17")
        if n > 0.0:
            return hexc("a8431c")
        return hexc("c8642e")

    def phobos(x, y, z):
        n = value_noise_sphere(x, y, z, 35, 6.0)
        return hexc("4a423c") if n > 0.2 else hexc("6a6058") if n > -0.3 else hexc("5a5049")

    def venus(x, y, z):
        n = value_noise_sphere(x, y * 2.5, z, 45, 3.5)
        return hexc("e8d6a0") if n > 0.15 else hexc("d6bd7c") if n > -0.15 else hexc("c9a868")

    def europa(x, y, z):
        n = value_noise_sphere(x, y, z, 55, 7.0)
        if abs(n) < 0.04:
            return hexc("9c5a3c")
        return hexc("e9e4d8") if n > 0 else hexc("d8cdb8")

    def jupiter(x, y, z):
        wobble = 0.05 * value_noise_sphere(x, y, z, 65, 6.0)
        band = y + wobble
        colors = ["c9a27a", "e8d8bd", "b0784f", "f2e6d0", "c18a5e", "e3cfae", "9e6b45", "efe2c8"]
        idx = int((band + 1) * 4.3) % len(colors)
        base = hexc(colors[idx])
        # Grande Mancha Vermelha
        sx, sy = x - 0.32, y - 0.28
        if (sx / 0.2) ** 2 + (sy / 0.1) ** 2 < 1:
            base = hexc("c0533a")
        return base

    save(planet(64, earth, atmosphere=hexc("7fb8ff")), "environment", "earth.png")
    save(planet(64, moon), "environment", "moon.png")
    save(planet(64, mars, atmosphere=hexc("e8a070")), "environment", "mars.png")
    save(planet(64, phobos), "environment", "phobos.png")
    save(planet(64, venus, atmosphere=hexc("fff0b0")), "environment", "venus.png")
    save(planet(64, europa), "environment", "europa.png")
    save(planet(128, jupiter, atmosphere=hexc("f5deb3")), "environment", "jupiter.png")


def make_icon():
    size = 128
    img = Image.new("RGBA", (size, size), hexc("0b0f1e"))
    px = img.load()
    rng = random.Random(3)
    for y in range(size):
        for x in range(size):
            t = y / size
            px[x, y] = (int(10 + 12 * t), int(14 + 8 * t), int(32 + 30 * t), 255)
    for _ in range(90):
        x, y = rng.randrange(size), rng.randrange(size)
        b = rng.randint(150, 255)
        px[x, y] = (b, b, min(255, b + 20), 255)
    mars_img = Image.open(os.path.join(ROOT, "environment", "mars.png")).resize((96, 96), Image.NEAREST)
    img.alpha_composite(mars_img, (52, 52))
    moon_img = Image.open(os.path.join(ROOT, "environment", "moon.png")).resize((32, 32), Image.NEAREST)
    img.alpha_composite(moon_img, (88, 10))
    rocket = Image.open(os.path.join(ROOT, "item", "rocket_tier_1.png")).resize((80, 80), Image.NEAREST)
    rocket = rocket.rotate(-28, resample=Image.NEAREST, expand=True)
    img.alpha_composite(rocket, (4, 10))
    path = os.path.join(ROOT, "..", "icon.png")
    img.save(path)


if __name__ == "__main__":
    make_blocks()
    make_items()
    make_armor()
    make_rocket_textures()
    make_planets()
    make_icon()
    print("texturas geradas")
