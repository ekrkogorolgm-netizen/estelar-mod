"""Gera os JSONs do mod: modelos, idiomas, dimensões, terreno, biomas, receitas, loot e tags.

Uso:  python3 tools/gen_data.py  [caminho para os dados vanilla 1.21.1 (misode/mcmeta, branch 1.21.1-data)]
Os roteadores de terreno de Marte e Vênus são copiados dos presets vanilla "large_biomes" e "amplified";
se o caminho não for passado, usa os arquivos já gerados em src/main/resources.
"""
import copy
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "src", "main", "resources")
ASSETS = os.path.join(RES, "assets", "estelar")
DATA = os.path.join(RES, "data", "estelar")
MC_DATA = os.path.join(RES, "data", "minecraft")
NS = "estelar"


def write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write("\n")


def read(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ======================================================================
# Blocos e itens
# ======================================================================
BLOCKS = ["moon_regolith", "moon_rock", "moon_titanium_ore", "mars_sand", "mars_rock", "mars_crystal_ore",
          "phobos_rock", "venus_rock", "europa_ice", "europa_rock", "titanium_block"]
ITEMS = ["raw_titanium", "titanium_ingot", "mars_crystal", "fuel_canister", "rocket_engine",
         "rocket_tier_1", "rocket_tier_2", "rocket_tier_3",
         "space_helmet", "space_chestplate", "space_leggings", "space_boots"]


def gen_models():
    for b in BLOCKS:
        write(f"{ASSETS}/blockstates/{b}.json", {"variants": {"": {"model": f"{NS}:block/{b}"}}})
        write(f"{ASSETS}/models/block/{b}.json", {"parent": "minecraft:block/cube_all", "textures": {"all": f"{NS}:block/{b}"}})
        write(f"{ASSETS}/models/item/{b}.json", {"parent": f"{NS}:block/{b}"})
    for i in ITEMS:
        write(f"{ASSETS}/models/item/{i}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"{NS}:item/{i}"}})


# ======================================================================
# Idiomas
# ======================================================================
LANG = {
    "pt_br": {
        "itemGroup.estelar": "Estelar",
        "entity.estelar.rocket": "Foguete",
        "block.estelar.moon_regolith": "Regolito Lunar",
        "block.estelar.moon_rock": "Rocha Lunar",
        "block.estelar.moon_titanium_ore": "Minério de Titânio Lunar",
        "block.estelar.mars_sand": "Areia Marciana",
        "block.estelar.mars_rock": "Rocha Marciana",
        "block.estelar.mars_crystal_ore": "Minério de Cristal Marciano",
        "block.estelar.phobos_rock": "Rocha de Fobos",
        "block.estelar.venus_rock": "Rocha Venusiana",
        "block.estelar.europa_ice": "Gelo de Europa",
        "block.estelar.europa_rock": "Rocha de Europa",
        "block.estelar.titanium_block": "Bloco de Titânio",
        "item.estelar.raw_titanium": "Titânio Bruto",
        "item.estelar.titanium_ingot": "Lingote de Titânio",
        "item.estelar.mars_crystal": "Cristal Marciano",
        "item.estelar.fuel_canister": "Galão de Combustível",
        "item.estelar.rocket_engine": "Motor de Foguete",
        "item.estelar.rocket_tier_1": "Foguete Nível I",
        "item.estelar.rocket_tier_2": "Foguete Nível II",
        "item.estelar.rocket_tier_3": "Foguete Nível III",
        "item.estelar.space_helmet": "Capacete Espacial",
        "item.estelar.space_chestplate": "Traje Espacial",
        "item.estelar.space_leggings": "Calças Espaciais",
        "item.estelar.space_boots": "Botas Espaciais",
        "biome.estelar.lunar_plains": "Planícies Lunares",
        "biome.estelar.martian_desert": "Deserto Marciano",
        "biome.estelar.phobos_surface": "Superfície de Fobos",
        "biome.estelar.venusian_wastes": "Ermos Venusianos",
        "biome.estelar.europa_ice_shell": "Casca de Gelo de Europa",
        "body.estelar.earth": "Terra",
        "body.estelar.moon": "Lua",
        "body.estelar.mars": "Marte",
        "body.estelar.phobos": "Fobos",
        "body.estelar.venus": "Vênus",
        "body.estelar.europa": "Europa",
        "message.estelar.tank_full": "O tanque já está cheio!",
        "message.estelar.fuel": "Combustível: %s / %s",
        "message.estelar.boarded": "Combustível: %s / %s — aperte ESPAÇO para abrir o painel de navegação",
        "message.estelar.hit_to_break": "Bata mais %s vez(es) para desmontar o foguete",
        "message.estelar.no_space": "Não há espaço para o foguete aqui!",
        "message.estelar.rocket_placed": "Foguete pronto! Abasteça com Galões de Combustível e entre nele.",
        "message.estelar.already_here": "Você já está aqui!",
        "message.estelar.tier_too_low": "Este foguete é fraco demais. Precisa de um Foguete Nível %s.",
        "message.estelar.not_enough_fuel": "Combustível insuficiente: precisa de %s, tem %s.",
        "message.estelar.countdown": "Contagem regressiva iniciada! Destino: %s",
        "message.estelar.world_missing": "Esse destino não existe neste mundo. O foguete vai pousar de volta.",
        "message.estelar.landed": "Pouso concluído.",
        "message.estelar.no_air_warning": "⚠ Não há ar respirável aqui! Use o traje espacial completo (4 peças) antes de sair do foguete.",
        "message.estelar.no_oxygen": "⚠ Sem oxigênio! Vista o traje espacial completo.",
        "title.estelar.liftoff": "DECOLAGEM!",
        "title.estelar.welcome": "Bem-vindo a %s",
        "subtitle.estelar.gravity": "Gravidade: %sg",
        "tooltip.estelar.fuel_canister": "Adiciona %s de combustível a um foguete",
        "tooltip.estelar.fuel_canister.use": "Clique com o botão direito no foguete",
        "tooltip.estelar.space_suit": "Vista as 4 peças para respirar no espaço",
        "tooltip.estelar.rocket.tier": "Nível %s",
        "tooltip.estelar.rocket.reach": "Alcança:",
        "tooltip.estelar.rocket.tank": "Tanque: %s de combustível",
        "tooltip.estelar.rocket.howto": "Coloque no chão, abasteça e entre (botão direito)",
        "screen.estelar.navigation": "Painel de Navegação",
        "screen.estelar.here": " (aqui)",
        "screen.estelar.info.gravity": "Gravidade: %sg",
        "screen.estelar.info.air_yes": "Ar: respirável",
        "screen.estelar.info.air_no": "Ar: nenhum (use o traje!)",
        "screen.estelar.info.tier": "Foguete mínimo: Nível %s",
        "screen.estelar.info.cost": "Combustível da viagem: %s",
        "screen.estelar.info.need_tier": "Precisa de um Foguete Nível %s",
        "screen.estelar.info.need_fuel": "Combustível insuficiente",
        "screen.estelar.unknown_place": "Lugar desconhecido",
        "screen.estelar.location": "Local: %s  •  Foguete Nível %s",
        "screen.estelar.fuel": "Combustível %s / %s",
        "screen.estelar.hint": "Escolha um destino para iniciar a contagem regressiva",
    },
    "en_us": {
        "itemGroup.estelar": "Estelar",
        "entity.estelar.rocket": "Rocket",
        "block.estelar.moon_regolith": "Lunar Regolith",
        "block.estelar.moon_rock": "Moon Rock",
        "block.estelar.moon_titanium_ore": "Lunar Titanium Ore",
        "block.estelar.mars_sand": "Martian Sand",
        "block.estelar.mars_rock": "Martian Rock",
        "block.estelar.mars_crystal_ore": "Martian Crystal Ore",
        "block.estelar.phobos_rock": "Phobos Rock",
        "block.estelar.venus_rock": "Venusian Rock",
        "block.estelar.europa_ice": "Europan Ice",
        "block.estelar.europa_rock": "Europan Rock",
        "block.estelar.titanium_block": "Block of Titanium",
        "item.estelar.raw_titanium": "Raw Titanium",
        "item.estelar.titanium_ingot": "Titanium Ingot",
        "item.estelar.mars_crystal": "Martian Crystal",
        "item.estelar.fuel_canister": "Fuel Canister",
        "item.estelar.rocket_engine": "Rocket Engine",
        "item.estelar.rocket_tier_1": "Tier I Rocket",
        "item.estelar.rocket_tier_2": "Tier II Rocket",
        "item.estelar.rocket_tier_3": "Tier III Rocket",
        "item.estelar.space_helmet": "Space Helmet",
        "item.estelar.space_chestplate": "Space Suit",
        "item.estelar.space_leggings": "Space Leggings",
        "item.estelar.space_boots": "Space Boots",
        "biome.estelar.lunar_plains": "Lunar Plains",
        "biome.estelar.martian_desert": "Martian Desert",
        "biome.estelar.phobos_surface": "Phobos Surface",
        "biome.estelar.venusian_wastes": "Venusian Wastes",
        "biome.estelar.europa_ice_shell": "Europan Ice Shell",
        "body.estelar.earth": "Earth",
        "body.estelar.moon": "Moon",
        "body.estelar.mars": "Mars",
        "body.estelar.phobos": "Phobos",
        "body.estelar.venus": "Venus",
        "body.estelar.europa": "Europa",
        "message.estelar.tank_full": "The tank is already full!",
        "message.estelar.fuel": "Fuel: %s / %s",
        "message.estelar.boarded": "Fuel: %s / %s — press SPACE to open the navigation panel",
        "message.estelar.hit_to_break": "Hit %s more time(s) to dismantle the rocket",
        "message.estelar.no_space": "Not enough room for the rocket here!",
        "message.estelar.rocket_placed": "Rocket ready! Refuel it with Fuel Canisters and climb in.",
        "message.estelar.already_here": "You are already here!",
        "message.estelar.tier_too_low": "This rocket is too weak. You need a Tier %s Rocket.",
        "message.estelar.not_enough_fuel": "Not enough fuel: needs %s, has %s.",
        "message.estelar.countdown": "Countdown started! Destination: %s",
        "message.estelar.world_missing": "That destination doesn't exist in this world. The rocket will land back.",
        "message.estelar.landed": "Landing complete.",
        "message.estelar.no_air_warning": "⚠ There is no breathable air here! Wear the full space suit (4 pieces) before leaving the rocket.",
        "message.estelar.no_oxygen": "⚠ No oxygen! Wear the full space suit.",
        "title.estelar.liftoff": "LIFTOFF!",
        "title.estelar.welcome": "Welcome to %s",
        "subtitle.estelar.gravity": "Gravity: %sg",
        "tooltip.estelar.fuel_canister": "Adds %s fuel to a rocket",
        "tooltip.estelar.fuel_canister.use": "Right-click the rocket",
        "tooltip.estelar.space_suit": "Wear all 4 pieces to breathe in space",
        "tooltip.estelar.rocket.tier": "Tier %s",
        "tooltip.estelar.rocket.reach": "Reaches:",
        "tooltip.estelar.rocket.tank": "Tank: %s fuel",
        "tooltip.estelar.rocket.howto": "Place it, refuel it and climb in (right-click)",
        "screen.estelar.navigation": "Navigation Panel",
        "screen.estelar.here": " (here)",
        "screen.estelar.info.gravity": "Gravity: %sg",
        "screen.estelar.info.air_yes": "Air: breathable",
        "screen.estelar.info.air_no": "Air: none (wear the suit!)",
        "screen.estelar.info.tier": "Minimum rocket: Tier %s",
        "screen.estelar.info.cost": "Trip fuel: %s",
        "screen.estelar.info.need_tier": "Needs a Tier %s Rocket",
        "screen.estelar.info.need_fuel": "Not enough fuel",
        "screen.estelar.unknown_place": "Unknown place",
        "screen.estelar.location": "Location: %s  •  Tier %s Rocket",
        "screen.estelar.fuel": "Fuel %s / %s",
        "screen.estelar.hint": "Pick a destination to start the countdown",
    },
}


def gen_lang():
    assert LANG["pt_br"].keys() == LANG["en_us"].keys()
    for code, entries in LANG.items():
        write(f"{ASSETS}/lang/{code}.json", entries)


# ======================================================================
# Terreno
# ======================================================================
def gradient(zero_y):
    """Densidade que vale 0 em zero_y, positiva abaixo, -1 a cada 32 blocos acima."""
    return {"type": "minecraft:y_clamped_gradient", "from_y": -64, "to_y": 320,
            "from_value": (zero_y + 64) / 32.0, "to_value": (zero_y - 320) / 32.0}


def noise(name, xz=1.0, y=0.0):
    return {"type": "minecraft:noise", "noise": f"{NS}:{name}", "xz_scale": xz, "y_scale": y}


def add(*args):
    out = args[0]
    for a in args[1:]:
        out = {"type": "minecraft:add", "argument1": out, "argument2": a}
    return out


def mul(k, f):
    return {"type": "minecraft:mul", "argument1": k, "argument2": f}


def clamp(f, lo, hi):
    return {"type": "minecraft:clamp", "input": f, "min": lo, "max": hi}


def maxf(a, b):
    return {"type": "minecraft:max", "argument1": a, "argument2": b}


def absf(f):
    return {"type": "minecraft:abs", "argument": f}


NOISES = {
    "moon_hills": (-8, [1.0, 0.6, 0.3]),
    "moon_highlands": (-10, [1.0, 0.5]),
    "moon_detail": (-5, [1.0, 0.5]),
    "phobos_rough": (-7, [1.0, 0.5, 0.5, 0.25]),
    "phobos_3d": (-5, [1.0, 0.5]),
    "europa_plains": (-7, [1.0, 0.5, 0.25]),
    "europa_ridges": (-6, [1.0]),
}


def custom_router(terrain_2d, extra_3d=None):
    final = terrain_2d if extra_3d is None else add(terrain_2d, extra_3d)
    router = {k: 0.0 for k in ["barrier", "fluid_level_floodedness", "fluid_level_spread", "lava", "temperature",
                                 "vegetation", "continents", "erosion", "depth", "ridges", "vein_toggle", "vein_ridged", "vein_gap"]}
    router["initial_density_without_jaggedness"] = terrain_2d
    router["final_density"] = {"type": "minecraft:interpolated", "argument": final}
    return router


def block(name, props=None):
    state = {"Name": name}
    if props:
        state["Properties"] = props
    return {"type": "minecraft:block", "result_state": state}


def cond(test, then):
    return {"type": "minecraft:condition", "if_true": test, "then_run": then}


def seq(*rules):
    return {"type": "minecraft:sequence", "sequence": list(rules)}


def floor_depth(add_surface=False, offset=0):
    return {"type": "minecraft:stone_depth", "offset": offset, "surface_type": "floor",
            "add_surface_depth": add_surface, "secondary_depth_range": 0}


def noise_patch(noise_name, lo, hi=10.0):
    return {"type": "minecraft:noise_threshold", "noise": noise_name, "min_threshold": lo, "max_threshold": hi}


BEDROCK_FLOOR = cond({"type": "minecraft:vertical_gradient", "random_name": "minecraft:bedrock_floor",
                      "true_at_and_below": {"above_bottom": 0}, "false_at_and_above": {"above_bottom": 5}},
                     block("minecraft:bedrock"))


def surface_rule(top_rules, under):
    """top_rules: regras para o bloco do topo; under: bloco das camadas logo abaixo."""
    return seq(
        BEDROCK_FLOOR,
        cond({"type": "minecraft:above_preliminary_surface"}, seq(
            cond(floor_depth(), seq(*top_rules)),
            cond(floor_depth(add_surface=True), block(under)),
        )),
    )


def noise_settings(default_block, router, surface, sea_level=-64, fluid="minecraft:air"):
    return {
        "sea_level": sea_level,
        "disable_mob_generation": True,
        "aquifers_enabled": False,
        "ore_veins_enabled": False,
        "legacy_random_source": False,
        "default_block": {"Name": default_block},
        "default_fluid": {"Name": fluid, "Properties": {"level": "0"}} if fluid != "minecraft:air" else {"Name": fluid},
        "noise": {"min_y": -64, "height": 384, "size_horizontal": 1, "size_vertical": 2},
        "noise_router": router,
        "spawn_target": [],
        "surface_rule": surface,
    }


def gen_worldgen(vanilla):
    for name, (first, amps) in NOISES.items():
        write(f"{DATA}/worldgen/noise/{name}.json", {"firstOctave": first, "amplitudes": amps})

    # --- Lua: planícies com colinas suaves e planaltos raros
    moon_terrain = add(
        gradient(64),
        mul(1.5, noise("moon_hills")),
        mul(1.6, maxf(0.0, add(-0.15, noise("moon_highlands")))),
        mul(0.12, noise("moon_detail")),
    )
    write(f"{DATA}/worldgen/noise_settings/moon.json", noise_settings(
        f"{NS}:moon_rock", custom_router(moon_terrain),
        surface_rule([block(f"{NS}:moon_regolith")], f"{NS}:moon_regolith")))

    # --- Fobos: pequeno, áspero, cheio de saliências
    phobos_terrain = add(gradient(70), mul(2.0, noise("phobos_rough")))
    write(f"{DATA}/worldgen/noise_settings/phobos.json", noise_settings(
        f"{NS}:phobos_rock", custom_router(phobos_terrain, mul(0.45, noise("phobos_3d", 1.0, 1.0))),
        surface_rule([cond(noise_patch("minecraft:gravel", 0.25), block("minecraft:gravel")),
                      block(f"{NS}:phobos_rock")], f"{NS}:phobos_rock")))

    # --- Europa: oceano congelado com cristas de gelo
    europa_terrain = add(
        gradient(59),
        mul(0.45, noise("europa_plains")),
        mul(1.0, clamp(add(0.25, mul(-2.5, absf(noise("europa_ridges")))), 0.0, 1.0)),
    )
    europa_surface = seq(
        BEDROCK_FLOOR,
        cond({"type": "minecraft:above_preliminary_surface"}, seq(
            cond(floor_depth(), seq(
                cond({"type": "minecraft:water", "offset": 0, "surface_depth_multiplier": 0, "add_stone_depth": False},
                     block(f"{NS}:europa_ice")),
                block("minecraft:gravel"))),
            cond(floor_depth(add_surface=True), seq(
                cond({"type": "minecraft:water", "offset": 0, "surface_depth_multiplier": 0, "add_stone_depth": False},
                     block("minecraft:packed_ice")),
                block(f"{NS}:europa_rock"))),
        )),
    )
    write(f"{DATA}/worldgen/noise_settings/europa.json", noise_settings(
        f"{NS}:europa_rock", custom_router(europa_terrain), europa_surface, sea_level=63, fluid="minecraft:water"))

    # --- Marte e Vênus: roteadores vanilla (montanhas, vales e bacias secas)
    settings_dir = f"{DATA}/worldgen/noise_settings"
    if vanilla:
        mars_router = read(f"{vanilla}/data/minecraft/worldgen/noise_settings/large_biomes.json")["noise_router"]
        venus_router = read(f"{vanilla}/data/minecraft/worldgen/noise_settings/amplified.json")["noise_router"]
    else:
        mars_router = read(f"{settings_dir}/mars.json")["noise_router"]
        venus_router = read(f"{settings_dir}/venus.json")["noise_router"]

    write(f"{settings_dir}/mars.json", noise_settings(
        f"{NS}:mars_rock", copy.deepcopy(mars_router),
        surface_rule([cond({"type": "minecraft:steep"}, block(f"{NS}:mars_rock")),
                      cond(noise_patch("minecraft:surface", 0.45), block("minecraft:red_sand")),
                      block(f"{NS}:mars_sand")], f"{NS}:mars_sand")))

    write(f"{settings_dir}/venus.json", noise_settings(
        f"{NS}:venus_rock", copy.deepcopy(venus_router),
        surface_rule([cond(noise_patch("minecraft:patch", 0.55), block("minecraft:magma_block")),
                      cond(noise_patch("minecraft:surface", 0.3), block("minecraft:basalt", {"axis": "y"})),
                      block(f"{NS}:venus_rock")], f"{NS}:venus_rock"),
        sea_level=32, fluid="minecraft:lava"))

    gen_dimensions()
    gen_biomes_and_features()


PLANETS = {
    #            biome                tipo de céu                    ultrawarm
    "moon":   ("lunar_plains",      f"{NS}:space",            False),
    "mars":   ("martian_desert",    f"{NS}:thin_atmosphere",  False),
    "phobos": ("phobos_surface",    f"{NS}:space",            False),
    "venus":  ("venusian_wastes",   f"{NS}:thick_atmosphere", True),
    "europa": ("europa_ice_shell",  f"{NS}:space",            False),
}


def gen_dimensions():
    for planet, (biome, effects, ultrawarm) in PLANETS.items():
        write(f"{DATA}/dimension_type/{planet}.json", {
            "ambient_light": 0.0,
            "bed_works": True,
            "coordinate_scale": 1.0,
            "effects": effects,
            "has_ceiling": False,
            "has_raids": False,
            "has_skylight": True,
            "height": 384,
            "infiniburn": "#minecraft:infiniburn_overworld",
            "logical_height": 384,
            "min_y": -64,
            "monster_spawn_block_light_limit": 0,
            "monster_spawn_light_level": {"type": "minecraft:uniform", "max_inclusive": 7, "min_inclusive": 0},
            "natural": False,
            "piglin_safe": False,
            "respawn_anchor_works": False,
            "ultrawarm": ultrawarm,
        })
        write(f"{DATA}/dimension/{planet}.json", {
            "type": f"{NS}:{planet}",
            "generator": {
                "type": "minecraft:noise",
                "settings": f"{NS}:{planet}",
                "biome_source": {"type": "minecraft:fixed", "biome": f"{NS}:{biome}"},
            },
        })


EMPTY_SPAWNERS = {k: [] for k in ["ambient", "axolotls", "creature", "misc", "monster",
                                  "underground_water_creature", "water_ambient", "water_creature"]}
CARVERS = {"air": ["minecraft:cave", "minecraft:cave_extra_underground", "minecraft:canyon"]}


def ore(name, ore_block, target, size, count, lo, hi, air_discard=0.0):
    write(f"{DATA}/worldgen/configured_feature/{name}.json", {
        "type": "minecraft:ore",
        "config": {
            "discard_chance_on_air_exposure": air_discard,
            "size": size,
            "targets": [{"state": {"Name": ore_block},
                         "target": {"predicate_type": "minecraft:block_match", "block": target}}],
        },
    })
    write(f"{DATA}/worldgen/placed_feature/{name}.json", {
        "feature": f"{NS}:{name}",
        "placement": [
            {"type": "minecraft:count", "count": count},
            {"type": "minecraft:in_square"},
            {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform",
                                                           "min_inclusive": {"absolute": lo},
                                                           "max_inclusive": {"absolute": hi}}},
            {"type": "minecraft:biome"},
        ],
    })
    return f"{NS}:{name}"


def crater(name, chance):
    write(f"{DATA}/worldgen/configured_feature/crater.json", {"type": f"{NS}:crater", "config": {}})
    write(f"{DATA}/worldgen/placed_feature/{name}.json", {
        "feature": f"{NS}:crater",
        "placement": [
            {"type": "minecraft:rarity_filter", "chance": chance},
            {"type": "minecraft:in_square"},
            {"type": "minecraft:heightmap", "heightmap": "WORLD_SURFACE_WG"},
            {"type": "minecraft:biome"},
        ],
    })
    return f"{NS}:{name}"


def biome(name, temperature, sky, fog, local_mods, ores, top_layer=None, carvers=True, particle=None):
    features = [[] for _ in range(11)]
    features[2] = local_mods
    features[6] = ores
    if top_layer:
        features[10] = top_layer
    effects = {
        "fog_color": fog,
        "sky_color": sky,
        "water_color": 4159204,
        "water_fog_color": 329011,
        "mood_sound": {"block_search_extent": 8, "offset": 2.0, "sound": "minecraft:ambient.cave", "tick_delay": 6000},
    }
    if particle:
        effects["particle"] = particle
    write(f"{DATA}/worldgen/biome/{name}.json", {
        "has_precipitation": False,
        "temperature": temperature,
        "downfall": 0.0,
        "effects": effects,
        "spawners": EMPTY_SPAWNERS,
        "spawn_costs": {},
        "carvers": CARVERS if carvers else {},
        "features": features,
    })


def gen_biomes_and_features():
    biome("lunar_plains", 0.5, 0, 0,
          [crater("moon_crater", 3)],
          [ore("ore_titanium_moon", f"{NS}:moon_titanium_ore", f"{NS}:moon_rock", 7, 14, -64, 120),
           ore("ore_iron_moon", "minecraft:iron_ore", f"{NS}:moon_rock", 8, 8, -64, 100),
           ore("ore_coal_moon", "minecraft:coal_ore", f"{NS}:moon_rock", 12, 6, 0, 120)])

    biome("martian_desert", -0.4, 0xD9A066, 0xC98A5A,
          [crater("mars_crater", 14)],
          [ore("ore_crystal_mars", f"{NS}:mars_crystal_ore", f"{NS}:mars_rock", 5, 9, -48, 100),
           ore("ore_iron_mars", "minecraft:iron_ore", f"{NS}:mars_rock", 9, 12, -64, 160),
           ore("ore_redstone_mars", "minecraft:redstone_ore", f"{NS}:mars_rock", 8, 5, -64, 32)],
          particle={"options": {"type": "minecraft:white_ash"}, "probability": 0.002})

    biome("phobos_surface", 0.5, 0, 0,
          [crater("phobos_crater", 2)],
          [ore("ore_titanium_phobos", f"{NS}:moon_titanium_ore", f"{NS}:phobos_rock", 7, 16, -64, 160)])

    biome("venusian_wastes", 2.0, 0xE8C46A, 0xD9B25C, [],
          [ore("ore_gold_venus", "minecraft:gold_ore", f"{NS}:venus_rock", 9, 14, -64, 200),
           ore("ore_diamond_venus", "minecraft:diamond_ore", f"{NS}:venus_rock", 6, 7, -64, 64, 0.5)],
          particle={"options": {"type": "minecraft:white_ash"}, "probability": 0.03})

    biome("europa_ice_shell", -1.0, 0, 0,
          ["minecraft:iceberg_packed", "minecraft:iceberg_blue"],
          [ore("ore_titanium_europa", f"{NS}:moon_titanium_ore", f"{NS}:europa_rock", 7, 8, -64, 40),
           ore("ore_lapis_europa", "minecraft:lapis_ore", f"{NS}:europa_rock", 7, 6, -64, 40)],
          top_layer=["minecraft:freeze_top_layer"], carvers=False)


# ======================================================================
# Receitas
# ======================================================================
def item(i):
    return {"item": i if ":" in i else f"{NS}:{i}"}


def shaped(name, pattern, key, result, count=1, category="misc"):
    write(f"{DATA}/recipe/{name}.json", {
        "type": "minecraft:crafting_shaped", "category": category,
        "key": {k: (v if isinstance(v, (dict, list)) else item(v)) for k, v in key.items()},
        "pattern": pattern,
        "result": {"count": count, "id": result if ":" in result else f"{NS}:{result}"},
    })


def shapeless(name, ingredients, result, count=1):
    write(f"{DATA}/recipe/{name}.json", {
        "type": "minecraft:crafting_shapeless", "category": "misc",
        "ingredients": [i if isinstance(i, (dict, list)) else item(i) for i in ingredients],
        "result": {"count": count, "id": f"{NS}:{result}"},
    })


def cooking(name, kind, ingredient, result, xp, time):
    write(f"{DATA}/recipe/{name}.json", {
        "type": f"minecraft:{kind}", "category": "misc", "cookingtime": time, "experience": xp,
        "group": "titanium_ingot", "ingredient": item(ingredient), "result": {"id": f"{NS}:{result}"},
    })


def gen_recipes():
    coal = [{"item": "minecraft:coal"}, {"item": "minecraft:charcoal"}]
    shaped("rocket_engine", ["IGI", "IFI", "I I"],
           {"I": "minecraft:iron_ingot", "G": "minecraft:gunpowder", "F": "minecraft:furnace"}, "rocket_engine")
    shaped("rocket_tier_1", [" R ", "IGI", "IEI"],
           {"R": "minecraft:redstone", "I": "minecraft:iron_ingot", "G": "minecraft:glass_pane", "E": "rocket_engine"},
           "rocket_tier_1", category="misc")
    shaped("rocket_tier_2", [" T ", "TRT", "TET"],
           {"T": "titanium_ingot", "R": "rocket_tier_1", "E": "rocket_engine"}, "rocket_tier_2")
    shaped("rocket_tier_3", [" C ", "CRC", "DED"],
           {"C": "mars_crystal", "R": "rocket_tier_2", "D": "minecraft:diamond", "E": "rocket_engine"}, "rocket_tier_3")
    shapeless("fuel_canister", ["minecraft:iron_ingot", coal, coal, "minecraft:redstone"], "fuel_canister", 2)
    shapeless("fuel_canister_from_blaze_powder", ["minecraft:iron_ingot", "minecraft:blaze_powder"], "fuel_canister", 3)
    shaped("space_helmet", ["WIW", "WGW"],
           {"W": "minecraft:white_wool", "I": "minecraft:iron_ingot", "G": "minecraft:glass"}, "space_helmet", category="equipment")
    shaped("space_chestplate", ["W W", "IBI", "WWW"],
           {"W": "minecraft:white_wool", "I": "minecraft:iron_ingot", "B": "minecraft:glass_bottle"}, "space_chestplate", category="equipment")
    shaped("space_leggings", ["WWW", "W W", "I I"],
           {"W": "minecraft:white_wool", "I": "minecraft:iron_ingot"}, "space_leggings", category="equipment")
    shaped("space_boots", ["W W", "I I"],
           {"W": "minecraft:white_wool", "I": "minecraft:iron_ingot"}, "space_boots", category="equipment")
    cooking("titanium_ingot_from_smelting", "smelting", "raw_titanium", "titanium_ingot", 0.7, 200)
    cooking("titanium_ingot_from_blasting", "blasting", "raw_titanium", "titanium_ingot", 0.7, 100)
    cooking("titanium_ingot_from_smelting_ore", "smelting", "moon_titanium_ore", "titanium_ingot", 0.7, 200)
    cooking("titanium_ingot_from_blasting_ore", "blasting", "moon_titanium_ore", "titanium_ingot", 0.7, 100)
    shaped("titanium_block", ["TTT", "TTT", "TTT"], {"T": "titanium_ingot"}, "titanium_block", category="building")
    shapeless("titanium_ingot_from_block", ["titanium_block"], "titanium_ingot", 9)


# ======================================================================
# Loot e tags
# ======================================================================
SILK = {"condition": "minecraft:match_tool",
        "predicate": {"predicates": {"minecraft:enchantments": [
            {"enchantments": "minecraft:silk_touch", "levels": {"min": 1}}]}}}


def loot_self(b):
    write(f"{DATA}/loot_table/blocks/{b}.json", {
        "type": "minecraft:block",
        "pools": [{"bonus_rolls": 0.0, "conditions": [{"condition": "minecraft:survives_explosion"}],
                   "entries": [{"type": "minecraft:item", "name": f"{NS}:{b}"}], "rolls": 1.0}],
        "random_sequence": f"{NS}:blocks/{b}",
    })


def loot_ore(b, drop, min_count=1, max_count=1):
    functions = []
    if (min_count, max_count) != (1, 1):
        functions.append({"function": "minecraft:set_count", "add": False,
                          "count": {"type": "minecraft:uniform", "min": float(min_count), "max": float(max_count)}})
    functions += [{"enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops", "function": "minecraft:apply_bonus"},
                  {"function": "minecraft:explosion_decay"}]
    write(f"{DATA}/loot_table/blocks/{b}.json", {
        "type": "minecraft:block",
        "pools": [{"bonus_rolls": 0.0, "entries": [{"type": "minecraft:alternatives", "children": [
            {"type": "minecraft:item", "conditions": [SILK], "name": f"{NS}:{b}"},
            {"type": "minecraft:item", "functions": functions, "name": f"{NS}:{drop}"},
        ]}], "rolls": 1.0}],
        "random_sequence": f"{NS}:blocks/{b}",
    })


def tag(path, values):
    write(f"{MC_DATA}/tags/{path}.json", {"replace": False, "values": [v if ":" in v else f"{NS}:{v}" for v in values]})


def gen_loot_and_tags():
    for b in BLOCKS:
        if b not in ("moon_titanium_ore", "mars_crystal_ore"):
            loot_self(b)
    loot_ore("moon_titanium_ore", "raw_titanium")
    loot_ore("mars_crystal_ore", "mars_crystal", 1, 2)

    rocks = ["moon_rock", "moon_titanium_ore", "mars_rock", "mars_crystal_ore", "phobos_rock",
             "venus_rock", "europa_rock", "europa_ice", "titanium_block"]
    tag("block/mineable/pickaxe", rocks)
    tag("block/mineable/shovel", ["moon_regolith", "mars_sand"])
    tag("block/needs_stone_tool", ["moon_titanium_ore", "titanium_block"])
    tag("block/needs_iron_tool", ["mars_crystal_ore"])
    tag("block/overworld_carver_replaceables", ["moon_regolith", "moon_rock", "mars_sand", "mars_rock", "phobos_rock",
                                                "venus_rock", "europa_rock"])
    tag("item/head_armor", ["space_helmet"])
    tag("item/chest_armor", ["space_chestplate"])
    tag("item/leg_armor", ["space_leggings"])
    tag("item/foot_armor", ["space_boots"])


if __name__ == "__main__":
    vanilla_dir = sys.argv[1] if len(sys.argv) > 1 else None
    gen_models()
    gen_lang()
    gen_worldgen(vanilla_dir)
    gen_recipes()
    gen_loot_and_tags()
    print("dados gerados")
