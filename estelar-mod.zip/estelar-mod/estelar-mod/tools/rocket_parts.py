# Peças do modelo do foguete (pixels; y negativo = para cima).  nome, x, y, z, w, h, d
PARTS = [
    ("body_a",      -6, -52, -8, 12, 44, 16),
    ("body_b",      -8, -51, -6, 16, 42, 12),
    ("nozzle_low",  -6,  -4, -6, 12,  4, 12),
    ("nozzle_high", -4,  -8, -4,  8,  4,  8),
    ("nose1",       -6, -60, -6, 12,  8, 12),
    ("nose2",       -4, -66, -4,  8,  6,  8),
    ("nose3",       -2, -70, -2,  4,  4,  4),
    ("tip",         -1, -73, -1,  2,  3,  2),
    ("fin_east",     8, -22, -1,  6, 22,  2),
    ("fin_west",   -14, -22, -1,  6, 22,  2),
    ("fin_south",   -1, -22,  8,  2, 22,  6),
    ("fin_north",   -1, -22,-14,  2, 22,  6),
    ("window",      -3, -46, -9,  6,  6,  1),
]
TEX_W, TEX_H = 128, 128

def pack():
    """Empacota as regiões UV (2*(w+d) x (d+h)) em prateleiras."""
    order = sorted(PARTS, key=lambda p: -(p[6] + p[5]))
    x = y = shelf_h = 0
    uv = {}
    for name, px, py, pz, w, h, d in order:
        rw, rh = 2 * (w + d), d + h
        if x + rw > TEX_W:
            x, y = 0, y + shelf_h
            shelf_h = 0
        uv[name] = (x, y)
        x += rw
        shelf_h = max(shelf_h, rh)
    assert y + shelf_h <= TEX_H, "textura pequena demais"
    return uv

if __name__ == "__main__":
    for k, v in pack().items():
        print(k, v)
