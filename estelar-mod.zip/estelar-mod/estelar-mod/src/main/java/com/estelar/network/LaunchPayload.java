package com.estelar.network;

import com.estelar.Estelar;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente → servidor: "piloto escolheu o destino X". */
public record LaunchPayload(int destination) implements CustomPayload {
	public static final CustomPayload.Id<LaunchPayload> ID = new CustomPayload.Id<>(Estelar.id("launch"));
	public static final PacketCodec<RegistryByteBuf, LaunchPayload> CODEC =
			PacketCodec.tuple(PacketCodecs.VAR_INT, LaunchPayload::destination, LaunchPayload::new);

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}
