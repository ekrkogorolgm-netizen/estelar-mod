package com.estelar.space;

import com.estelar.Estelar;
import com.estelar.item.SpaceSuitItem;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

/**
 * Gravidade diferente em cada planeta e falta de ar fora da Terra.
 */
public final class SpaceEnvironment {
	private static final Identifier GRAVITY_MODIFIER = Estelar.id("planet_gravity");
	private static final Identifier FALL_DAMAGE_MODIFIER = Estelar.id("planet_fall_damage");

	private SpaceEnvironment() {
	}

	public static void init() {
		ServerTickEvents.END_WORLD_TICK.register(SpaceEnvironment::tickWorld);
	}

	private static void tickWorld(ServerWorld world) {
		CelestialBody body = CelestialBody.fromWorld(world.getRegistryKey());
		double gravity = body == null ? 1.0 : body.gravity();

		if (world.getTime() % 10 == 0) {
			for (Entity entity : world.iterateEntities()) {
				if (entity instanceof LivingEntity living) {
					applyModifier(living, EntityAttributes.GENERIC_GRAVITY, GRAVITY_MODIFIER, gravity - 1.0);
					applyModifier(living, EntityAttributes.GENERIC_FALL_DAMAGE_MULTIPLIER, FALL_DAMAGE_MODIFIER, gravity - 1.0);
				}
			}
		}

		if (body != null && !body.breathable()) {
			for (ServerPlayerEntity player : world.getPlayers()) {
				tickOxygen(world, player);
			}
		}
	}

	private static void applyModifier(LivingEntity entity, RegistryEntry<EntityAttribute> attribute, Identifier id, double value) {
		EntityAttributeInstance instance = entity.getAttributeInstance(attribute);
		if (instance == null) {
			return;
		}
		EntityAttributeModifier current = instance.getModifier(id);
		if (Math.abs(value) < 1.0E-6) {
			if (current != null) {
				instance.removeModifier(id);
			}
			return;
		}
		if (current != null && Math.abs(current.value() - value) < 1.0E-6) {
			return;
		}
		if (current != null) {
			instance.removeModifier(id);
		}
		instance.addTemporaryModifier(new EntityAttributeModifier(id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
	}

	private static void tickOxygen(ServerWorld world, ServerPlayerEntity player) {
		if (player.isCreative() || player.isSpectator() || !player.isAlive()) {
			return;
		}
		if (SpaceSuitItem.isWearingFullSuit(player)) {
			return;
		}
		// O Minecraft devolve +4 de ar por tick fora d'água; tiramos 6, então o ar cai 2 por tick.
		int air = Math.max(player.getAir() - 6, 0);
		player.setAir(air);

		if (air <= 4 && world.getTime() % 20 == 0) {
			player.damage(world.getDamageSources().drown(), 2.0f);
		}
		if (world.getTime() % 40 == 0) {
			player.sendMessage(Text.translatable("message.estelar.no_oxygen").formatted(Formatting.RED), true);
		}
	}
}
