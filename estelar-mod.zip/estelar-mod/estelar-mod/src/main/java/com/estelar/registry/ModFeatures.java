package com.estelar.registry;

import com.estelar.Estelar;
import com.estelar.world.CraterFeature;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;

public final class ModFeatures {
	public static final Feature<DefaultFeatureConfig> CRATER = Registry.register(Registries.FEATURE, Estelar.id("crater"),
			new CraterFeature(DefaultFeatureConfig.CODEC));

	private ModFeatures() {
	}

	public static void init() {
	}
}
