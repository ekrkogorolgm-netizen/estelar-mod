package com.estelar.item;

import com.estelar.entity.RocketEntity;
import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class FuelCanisterItem extends Item {
	public FuelCanisterItem(Settings settings) {
		super(settings);
	}

	@Override
	public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
		tooltip.add(Text.translatable("tooltip.estelar.fuel_canister", RocketEntity.FUEL_PER_CANISTER).formatted(Formatting.GRAY));
		tooltip.add(Text.translatable("tooltip.estelar.fuel_canister.use").formatted(Formatting.DARK_GRAY));
	}
}
