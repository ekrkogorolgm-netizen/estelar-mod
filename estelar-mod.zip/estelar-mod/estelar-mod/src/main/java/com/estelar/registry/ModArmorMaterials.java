package com.estelar.registry;

import com.estelar.Estelar;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Util;

public final class ModArmorMaterials {
	public static final RegistryEntry<ArmorMaterial> SPACE_SUIT = Registry.registerReference(
			Registries.ARMOR_MATERIAL,
			Estelar.id("space_suit"),
			new ArmorMaterial(
					Util.make(new EnumMap<ArmorItem.Type, Integer>(ArmorItem.Type.class), map -> {
						map.put(ArmorItem.Type.BOOTS, 2);
						map.put(ArmorItem.Type.LEGGINGS, 4);
						map.put(ArmorItem.Type.CHESTPLATE, 5);
						map.put(ArmorItem.Type.HELMET, 2);
						map.put(ArmorItem.Type.BODY, 4);
					}),
					12,
					SoundEvents.ITEM_ARMOR_EQUIP_IRON,
					() -> Ingredient.ofItems(Items.WHITE_WOOL),
					List.of(new ArmorMaterial.Layer(Estelar.id("space_suit"))),
					0.5f,
					0.0f));

	private ModArmorMaterials() {
	}

	public static void init() {
	}
}
