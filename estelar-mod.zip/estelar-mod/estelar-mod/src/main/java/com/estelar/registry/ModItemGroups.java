package com.estelar.registry;

import com.estelar.Estelar;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class ModItemGroups {
	public static final ItemGroup ESTELAR = Registry.register(Registries.ITEM_GROUP, Estelar.id("estelar"),
			FabricItemGroup.builder()
					.icon(() -> new ItemStack(ModItems.ROCKET_TIER_1))
					.displayName(Text.translatable("itemGroup.estelar"))
					.entries((context, entries) -> {
						entries.add(ModItems.ROCKET_TIER_1);
						entries.add(ModItems.ROCKET_TIER_2);
						entries.add(ModItems.ROCKET_TIER_3);
						entries.add(ModItems.ROCKET_ENGINE);
						entries.add(ModItems.FUEL_CANISTER);
						entries.add(ModItems.SPACE_HELMET);
						entries.add(ModItems.SPACE_CHESTPLATE);
						entries.add(ModItems.SPACE_LEGGINGS);
						entries.add(ModItems.SPACE_BOOTS);
						entries.add(ModItems.RAW_TITANIUM);
						entries.add(ModItems.TITANIUM_INGOT);
						entries.add(ModItems.MARS_CRYSTAL);
						entries.add(ModBlocks.TITANIUM_BLOCK);
						entries.add(ModBlocks.MOON_REGOLITH);
						entries.add(ModBlocks.MOON_ROCK);
						entries.add(ModBlocks.MOON_TITANIUM_ORE);
						entries.add(ModBlocks.MARS_SAND);
						entries.add(ModBlocks.MARS_ROCK);
						entries.add(ModBlocks.MARS_CRYSTAL_ORE);
						entries.add(ModBlocks.PHOBOS_ROCK);
						entries.add(ModBlocks.VENUS_ROCK);
						entries.add(ModBlocks.EUROPA_ICE);
						entries.add(ModBlocks.EUROPA_ROCK);
					})
					.build());

	private ModItemGroups() {
	}

	public static void init() {
	}
}
