package com.estelar.network;

import com.estelar.entity.RocketEntity;
import com.estelar.space.CelestialBody;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

public final class ModNetworking {
	private ModNetworking() {
	}

	public static void init() {
		PayloadTypeRegistry.playC2S().register(LaunchPayload.ID, LaunchPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(LaunchPayload.ID, (payload, context) -> {
			ServerPlayerEntity player = context.player();
			CelestialBody target = CelestialBody.byIndex(payload.destination());
			if (target != null && player.getVehicle() instanceof RocketEntity rocket) {
				rocket.requestLaunch(player, target);
			}
		});
	}
}
