package com.estelar;

import com.estelar.network.ModNetworking;
import com.estelar.registry.ModArmorMaterials;
import com.estelar.registry.ModBlocks;
import com.estelar.registry.ModEntities;
import com.estelar.registry.ModFeatures;
import com.estelar.registry.ModItemGroups;
import com.estelar.registry.ModItems;
import com.estelar.space.SpaceEnvironment;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Estelar: foguetes, planetas e luas para o Minecraft.
 */
public class Estelar implements ModInitializer {
	public static final String MOD_ID = "estelar";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.of(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModArmorMaterials.init();
		ModBlocks.init();
		ModItems.init();
		ModEntities.init();
		ModFeatures.init();
		ModItemGroups.init();
		ModNetworking.init();
		SpaceEnvironment.init();
		LOGGER.info("Estelar carregado: preparem os foguetes!");
	}
}
