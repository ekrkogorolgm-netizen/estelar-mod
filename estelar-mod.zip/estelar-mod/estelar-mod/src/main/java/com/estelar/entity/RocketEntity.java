package com.estelar.entity;

import com.estelar.registry.ModBlocks;
import com.estelar.registry.ModEntities;
import com.estelar.registry.ModItems;
import com.estelar.space.CelestialBody;
import java.util.UUID;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.EntityTrackerEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.TeleportTarget;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * O foguete. Fica parado no chão (IDLE), faz a contagem regressiva (COUNTDOWN),
 * sobe (ASCENT), é transferido para outro mundo e então pousa devagar (LANDING).
 */
public class RocketEntity extends Entity {
	public static final int PHASE_IDLE = 0;
	public static final int PHASE_COUNTDOWN = 1;
	public static final int PHASE_ASCENT = 2;
	public static final int PHASE_LANDING = 3;

	public static final int FUEL_PER_CANISTER = 25;
	private static final int COUNTDOWN_TICKS = 61;
	private static final int ASCENT_TICKS = 160;

	private static final TrackedData<Integer> TIER = DataTracker.registerData(RocketEntity.class, TrackedDataHandlerRegistry.INTEGER);
	private static final TrackedData<Integer> FUEL = DataTracker.registerData(RocketEntity.class, TrackedDataHandlerRegistry.INTEGER);
	private static final TrackedData<Integer> PHASE = DataTracker.registerData(RocketEntity.class, TrackedDataHandlerRegistry.INTEGER);

	// Só no servidor
	private int phaseTicks;
	@Nullable
	private CelestialBody destination;
	@Nullable
	private CelestialBody arrivalBody;
	@Nullable
	private UUID pendingRider;
	private int pendingRiderTicks;
	private int hits;
	private int lastHitAge;

	// Só no cliente (movimento suave)
	private int lerpSteps;
	private double lerpX;
	private double lerpY;
	private double lerpZ;
	private float lerpYaw;

	public RocketEntity(EntityType<? extends RocketEntity> type, World world) {
		super(type, world);
	}

	public static int maxFuelForTier(int tier) {
		return 50 + 50 * MathHelper.clamp(tier, 1, 3);
	}

	// ------------------------------------------------------------------ dados

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(TIER, 1);
		builder.add(FUEL, 0);
		builder.add(PHASE, PHASE_IDLE);
	}

	public int getTier() {
		return this.dataTracker.get(TIER);
	}

	public void setTier(int tier) {
		this.dataTracker.set(TIER, MathHelper.clamp(tier, 1, 3));
	}

	public int getFuel() {
		return this.dataTracker.get(FUEL);
	}

	public void setFuel(int fuel) {
		this.dataTracker.set(FUEL, MathHelper.clamp(fuel, 0, getMaxFuel()));
	}

	public int getMaxFuel() {
		return maxFuelForTier(getTier());
	}

	public int getPhase() {
		return this.dataTracker.get(PHASE);
	}

	private void setPhase(int phase) {
		this.dataTracker.set(PHASE, phase);
		this.phaseTicks = 0;
		this.noClip = phase == PHASE_ASCENT;
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		setTier(nbt.getInt("Tier"));
		setFuel(nbt.getInt("Fuel"));
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putInt("Tier", getTier());
		nbt.putInt("Fuel", getFuel());
	}

	// --------------------------------------------------------- interação

	@Override
	public ActionResult interact(PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		World world = this.getWorld();

		if (stack.isOf(ModItems.FUEL_CANISTER)) {
			if (!world.isClient) {
				if (getFuel() >= getMaxFuel()) {
					player.sendMessage(Text.translatable("message.estelar.tank_full").formatted(Formatting.YELLOW), true);
				} else {
					setFuel(getFuel() + FUEL_PER_CANISTER);
					if (!player.getAbilities().creativeMode) {
						stack.decrement(1);
					}
					world.playSound(null, getX(), getY(), getZ(), SoundEvents.ITEM_BUCKET_EMPTY_LAVA, SoundCategory.NEUTRAL, 1.0f, 1.2f);
					player.sendMessage(Text.translatable("message.estelar.fuel", getFuel(), getMaxFuel()).formatted(Formatting.GOLD), true);
				}
			}
			return ActionResult.success(world.isClient);
		}

		if (player.shouldCancelInteraction() || hasPassengers() || getPhase() != PHASE_IDLE) {
			return ActionResult.PASS;
		}

		if (!world.isClient) {
			if (player.startRiding(this)) {
				player.sendMessage(Text.translatable("message.estelar.boarded", getFuel(), getMaxFuel()).formatted(Formatting.AQUA), true);
				return ActionResult.CONSUME;
			}
			return ActionResult.PASS;
		}
		return ActionResult.SUCCESS;
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		if (this.isInvulnerableTo(source) || this.isRemoved()) {
			return false;
		}
		if (this.getWorld().isClient) {
			return true;
		}
		if (!(source.getAttacker() instanceof PlayerEntity player) || getPhase() != PHASE_IDLE || hasPassengers()) {
			return false;
		}

		boolean creative = player.getAbilities().creativeMode;
		if (this.age - this.lastHitAge > 40) {
			this.hits = 0;
		}
		this.lastHitAge = this.age;
		this.hits++;

		if (!creative && this.hits < 3) {
			this.getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_METAL_HIT, SoundCategory.NEUTRAL, 1.0f, 0.8f);
			player.sendMessage(Text.translatable("message.estelar.hit_to_break", 3 - this.hits).formatted(Formatting.GRAY), true);
			return true;
		}

		if (!creative) {
			this.dropStack(new ItemStack(ModItems.rocketForTier(getTier())));
			int canisters = getFuel() / FUEL_PER_CANISTER;
			if (canisters > 0) {
				this.dropStack(new ItemStack(ModItems.FUEL_CANISTER, canisters));
			}
		}
		this.getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_METAL_BREAK, SoundCategory.NEUTRAL, 1.0f, 1.0f);
		this.discard();
		return true;
	}

	@Override
	public Packet<ClientPlayPacketListener> createSpawnPacket(EntityTrackerEntry entityTrackerEntry) {
		return new EntitySpawnS2CPacket(this, entityTrackerEntry);
	}

	@Override
	public boolean canHit() {
		return !this.isRemoved();
	}

	@Override
	public boolean isCollidable() {
		return true;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	@Override
	protected boolean canAddPassenger(Entity passenger) {
		return this.getPassengerList().isEmpty();
	}

	@Override
	public ItemStack getPickBlockStack() {
		return new ItemStack(ModItems.rocketForTier(getTier()));
	}

	@Override
	public Vec3d updatePassengerForDismount(LivingEntity passenger) {
		double[][] offsets = {{1.6, 0}, {-1.6, 0}, {0, 1.6}, {0, -1.6}, {1.6, 1.6}, {-1.6, -1.6}};
		for (double[] offset : offsets) {
			for (int dy = 0; dy <= 1; dy++) {
				Vec3d pos = new Vec3d(getX() + offset[0], getY() + dy, getZ() + offset[1]);
				Box box = passenger.getDimensions(EntityPose.STANDING).getBoxAt(pos);
				if (this.getWorld().isSpaceEmpty(passenger, box)) {
					return pos;
				}
			}
		}
		return super.updatePassengerForDismount(passenger);
	}

	// ------------------------------------------------------- lançamento

	/** Chamado pelo servidor quando o piloto escolhe um destino no painel. */
	public void requestLaunch(ServerPlayerEntity pilot, CelestialBody target) {
		if (getPhase() != PHASE_IDLE || pilot.getVehicle() != this) {
			return;
		}
		CelestialBody here = CelestialBody.fromWorld(this.getWorld().getRegistryKey());
		if (target == here) {
			pilot.sendMessage(Text.translatable("message.estelar.already_here").formatted(Formatting.RED), true);
			return;
		}
		if (target.tier() > getTier() || (here != null && here.tier() > getTier())) {
			pilot.sendMessage(Text.translatable("message.estelar.tier_too_low", target.tier()).formatted(Formatting.RED), true);
			return;
		}
		int cost = CelestialBody.fuelCost(here, target);
		if (getFuel() < cost) {
			pilot.sendMessage(Text.translatable("message.estelar.not_enough_fuel", cost, getFuel()).formatted(Formatting.RED), true);
			return;
		}
		this.destination = target;
		setPhase(PHASE_COUNTDOWN);
		pilot.sendMessage(Text.translatable("message.estelar.countdown", target.displayName()).formatted(Formatting.GOLD), true);
	}

	// ------------------------------------------------------------ tick

	@Override
	public void tick() {
		super.tick();
		if (this.getWorld().isClient) {
			tickClient();
			return;
		}
		ServerWorld world = (ServerWorld) this.getWorld();
		this.phaseTicks++;

		switch (getPhase()) {
			case PHASE_COUNTDOWN -> tickCountdown(world);
			case PHASE_ASCENT -> tickAscent(world);
			case PHASE_LANDING -> tickLanding(world);
			default -> tickIdle(world);
		}
	}

	private void tickIdle(ServerWorld world) {
		double vy;
		if (this.isTouchingWater() || this.isInLava()) {
			vy = 0.03; // boia
		} else {
			vy = Math.max(getVelocity().y - 0.04, -1.2);
		}
		setVelocity(0.0, vy, 0.0);
		move(MovementType.SELF, getVelocity());
		if (this.isOnGround()) {
			setVelocity(Vec3d.ZERO);
		}

		if (this.phaseTicks % 40 == 0 && getFirstPassenger() instanceof ServerPlayerEntity player) {
			player.sendMessage(Text.translatable("message.estelar.boarded", getFuel(), getMaxFuel()).formatted(Formatting.AQUA), true);
		}
	}

	private void tickCountdown(ServerWorld world) {
		Entity pilot = getFirstPassenger();
		if (pilot == null) {
			setPhase(PHASE_IDLE);
			return;
		}
		int ticksLeft = COUNTDOWN_TICKS - this.phaseTicks;
		if (ticksLeft > 0 && ticksLeft % 20 == 0 && pilot instanceof ServerPlayerEntity player) {
			int seconds = ticksLeft / 20;
			sendTitle(player, Text.literal(String.valueOf(seconds)).formatted(Formatting.GOLD, Formatting.BOLD), null);
			world.playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_NOTE_BLOCK_PLING, SoundCategory.NEUTRAL, 1.5f, 0.5f + 0.25f * (3 - seconds));
		}
		if (ticksLeft <= 0) {
			CelestialBody here = CelestialBody.fromWorld(world.getRegistryKey());
			if (this.destination == null || getFuel() < CelestialBody.fuelCost(here, this.destination)) {
				setPhase(PHASE_IDLE);
				return;
			}
			setFuel(getFuel() - CelestialBody.fuelCost(here, this.destination));
			setPhase(PHASE_ASCENT);
			if (pilot instanceof ServerPlayerEntity player) {
				sendTitle(player, Text.translatable("title.estelar.liftoff").formatted(Formatting.RED, Formatting.BOLD), null);
			}
			world.playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.NEUTRAL, 3.0f, 0.5f);
			world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY(), getZ(), 1, 0.0, 0.0, 0.0, 0.0);
		}
	}

	private void tickAscent(ServerWorld world) {
		if (getFirstPassenger() == null) {
			// O piloto saltou: o foguete desiste e volta a pousar aqui.
			this.destination = null;
			setPhase(PHASE_LANDING);
			return;
		}
		double speed = Math.min(0.05 + this.phaseTicks * 0.012, 1.6);
		setVelocity(0.0, speed, 0.0);
		move(MovementType.SELF, getVelocity());

		if (this.phaseTicks % 6 == 0) {
			world.playSound(null, getX(), getY(), getZ(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.NEUTRAL, 2.0f, 0.5f);
		}
		if (this.phaseTicks >= ASCENT_TICKS || getY() > world.getTopY() + 64) {
			travel(world);
		}
	}

	private void tickLanding(ServerWorld world) {
		if (this.pendingRider != null) {
			this.pendingRiderTicks++;
			PlayerEntity rider = world.getPlayerByUuid(this.pendingRider);
			if (rider != null && this.pendingRiderTicks >= 3) {
				rider.startRiding(this, true);
				rider.fallDistance = 0.0f;
				this.pendingRider = null;
			} else if (this.pendingRiderTicks > 100) {
				this.pendingRider = null;
			} else {
				setVelocity(Vec3d.ZERO);
				return;
			}
		}

		int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING, MathHelper.floor(getX()), MathHelper.floor(getZ()));
		double height = getY() - top;
		double speed = MathHelper.clamp(height * 0.035, 0.1, 0.9);
		setVelocity(0.0, -speed, 0.0);
		move(MovementType.SELF, getVelocity());

		if (this.phaseTicks % 8 == 0) {
			world.playSound(null, getX(), getY(), getZ(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.NEUTRAL, 1.0f, 0.7f);
		}

		if (this.isOnGround() || this.verticalCollision || this.isTouchingWater() || this.isInLava() || this.phaseTicks > 1200) {
			setPhase(PHASE_IDLE);
			setVelocity(Vec3d.ZERO);
			world.playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.NEUTRAL, 0.8f, 0.6f);
			world.spawnParticles(ParticleTypes.CLOUD, getX(), getY() + 0.2, getZ(), 30, 1.2, 0.1, 1.2, 0.05);
			if (getFirstPassenger() instanceof ServerPlayerEntity player) {
				player.fallDistance = 0.0f;
				if (this.arrivalBody != null) {
					Text subtitle = Text.translatable("subtitle.estelar.gravity",
							String.format("%.2f", this.arrivalBody.gravity())).formatted(Formatting.GRAY);
					sendTitle(player, Text.translatable("title.estelar.welcome", this.arrivalBody.displayName()).formatted(Formatting.AQUA), subtitle);
					if (!this.arrivalBody.breathable()) {
						player.sendMessage(Text.translatable("message.estelar.no_air_warning").formatted(Formatting.YELLOW), false);
					}
				} else {
					player.sendMessage(Text.translatable("message.estelar.landed").formatted(Formatting.GREEN), true);
				}
			}
			this.arrivalBody = null;
		}
	}

	/** Leva o foguete (e o piloto) para o mundo de destino. */
	private void travel(ServerWorld world) {
		CelestialBody target = this.destination;
		ServerWorld targetWorld = target == null || world.getServer() == null ? null : world.getServer().getWorld(target.worldKey());
		if (targetWorld == null) {
			Entity pilot = getFirstPassenger();
			if (pilot instanceof ServerPlayerEntity player) {
				player.sendMessage(Text.translatable("message.estelar.world_missing").formatted(Formatting.RED), false);
			}
			this.destination = null;
			setPhase(PHASE_LANDING);
			return;
		}

		BlockPos landing = findLandingSpot(targetWorld, MathHelper.floor(getX()), MathHelper.floor(getZ()));
		double x = landing.getX() + 0.5;
		double z = landing.getZ() + 0.5;
		double y = landing.getY() + 70.0;

		RocketEntity arriving = ModEntities.ROCKET.create(targetWorld);
		if (arriving == null) {
			return;
		}
		arriving.setTier(getTier());
		arriving.setFuel(getFuel());
		arriving.refreshPositionAndAngles(x, y, z, getYaw(), 0.0f);
		arriving.setPhase(PHASE_LANDING);
		arriving.arrivalBody = target;
		targetWorld.spawnEntity(arriving);

		Entity pilot = getFirstPassenger();
		if (pilot != null) {
			pilot.stopRiding();
			if (pilot instanceof ServerPlayerEntity player) {
				player.fallDistance = 0.0f;
				player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 200, 0, false, false, true));
				player.teleport(targetWorld, x, y + 1.5, z, player.getYaw(), player.getPitch());
				arriving.pendingRider = player.getUuid();
			} else {
				pilot.teleportTo(new TeleportTarget(targetWorld, new Vec3d(x, y + 1.5, z), Vec3d.ZERO,
						pilot.getYaw(), pilot.getPitch(), TeleportTarget.NO_OP));
			}
		}
		this.destination = null;
		this.discard();
	}

	/**
	 * Procura um lugar firme (sem lava nem água) perto de x/z. Se não achar,
	 * constrói uma pequena plataforma de pouso.
	 */
	private static BlockPos findLandingSpot(ServerWorld world, int x, int z) {
		int[] rings = {0, 16, 32, 48};
		for (int radius : rings) {
			for (int dx = -radius; dx <= radius; dx += 16) {
				for (int dz = -radius; dz <= radius; dz += 16) {
					if (radius != 0 && Math.abs(dx) != radius && Math.abs(dz) != radius) {
						continue;
					}
					int cx = x + dx;
					int cz = z + dz;
					world.getChunk(cx >> 4, cz >> 4);
					int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, cx, cz);
					if (top <= world.getBottomY()) {
						continue;
					}
					BlockPos ground = new BlockPos(cx, top - 1, cz);
					BlockState state = world.getBlockState(ground);
					if (state.getFluidState().isEmpty() && state.isSideSolidFullSquare(world, ground, Direction.UP)) {
						return ground.up();
					}
				}
			}
		}

		// Nenhum lugar seguro: faz uma plataforma sobre o que houver.
		world.getChunk(x >> 4, z >> 4);
		int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
		if (top <= world.getBottomY()) {
			top = 64;
		}
		BlockState platform = platformBlock(world);
		for (int dx = -2; dx <= 2; dx++) {
			for (int dz = -2; dz <= 2; dz++) {
				world.setBlockState(new BlockPos(x + dx, top, z + dz), platform);
			}
		}
		return new BlockPos(x, top + 1, z);
	}

	private static BlockState platformBlock(ServerWorld world) {
		CelestialBody body = CelestialBody.fromWorld(world.getRegistryKey());
		if (body == null) {
			return Blocks.COBBLESTONE.getDefaultState();
		}
		return switch (body) {
			case MOON -> ModBlocks.MOON_ROCK.getDefaultState();
			case MARS -> ModBlocks.MARS_ROCK.getDefaultState();
			case PHOBOS -> ModBlocks.PHOBOS_ROCK.getDefaultState();
			case VENUS -> ModBlocks.VENUS_ROCK.getDefaultState();
			case EUROPA -> ModBlocks.EUROPA_ICE.getDefaultState();
			default -> Blocks.COBBLESTONE.getDefaultState();
		};
	}

	private static void sendTitle(ServerPlayerEntity player, Text title, @Nullable Text subtitle) {
		player.networkHandler.sendPacket(new TitleFadeS2CPacket(5, 30, 10));
		if (subtitle != null) {
			player.networkHandler.sendPacket(new SubtitleS2CPacket(subtitle));
		}
		player.networkHandler.sendPacket(new TitleS2CPacket(title));
	}

	// --------------------------------------------------------- cliente

	@Override
	public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps) {
		this.lerpX = x;
		this.lerpY = y;
		this.lerpZ = z;
		this.lerpYaw = yaw;
		this.lerpSteps = 3;
	}

	private void tickClient() {
		if (this.lerpSteps > 0) {
			this.lerpPosAndRotation(this.lerpSteps, this.lerpX, this.lerpY, this.lerpZ, this.lerpYaw, this.getPitch());
			this.lerpSteps--;
		}

		World world = this.getWorld();
		Random random = this.getRandom();
		double x = getX();
		double y = getY();
		double z = getZ();

		switch (getPhase()) {
			case PHASE_COUNTDOWN -> {
				for (int i = 0; i < 3; i++) {
					double angle = random.nextDouble() * Math.PI * 2;
					world.addParticle(ParticleTypes.CLOUD, x, y + 0.2, z,
							Math.cos(angle) * 0.25, 0.01, Math.sin(angle) * 0.25);
				}
				if (random.nextInt(3) == 0) {
					world.addParticle(ParticleTypes.SMALL_FLAME, x + random.nextGaussian() * 0.2, y + 0.1, z + random.nextGaussian() * 0.2,
							0.0, -0.05, 0.0);
				}
			}
			case PHASE_ASCENT -> {
				for (int i = 0; i < 6; i++) {
					world.addParticle(ParticleTypes.FLAME, x + random.nextGaussian() * 0.18, y - 0.1, z + random.nextGaussian() * 0.18,
							random.nextGaussian() * 0.03, -0.6 - random.nextDouble() * 0.4, random.nextGaussian() * 0.03);
				}
				for (int i = 0; i < 3; i++) {
					world.addParticle(ParticleTypes.LARGE_SMOKE, x + random.nextGaussian() * 0.3, y - 0.6, z + random.nextGaussian() * 0.3,
							random.nextGaussian() * 0.05, -0.2, random.nextGaussian() * 0.05);
				}
				world.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y - 1.0, z, random.nextGaussian() * 0.02, 0.02, random.nextGaussian() * 0.02);
			}
			case PHASE_LANDING -> {
				for (int i = 0; i < 3; i++) {
					world.addParticle(ParticleTypes.FLAME, x + random.nextGaussian() * 0.15, y - 0.1, z + random.nextGaussian() * 0.15,
							0.0, -0.5 - random.nextDouble() * 0.3, 0.0);
				}
				world.addParticle(ParticleTypes.SMOKE, x + random.nextGaussian() * 0.2, y - 0.3, z + random.nextGaussian() * 0.2, 0.0, -0.1, 0.0);
			}
			default -> {
			}
		}
	}
}
