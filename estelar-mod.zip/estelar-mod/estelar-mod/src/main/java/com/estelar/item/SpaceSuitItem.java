package com.estelar.item;

import com.estelar.registry.ModArmorMaterials;
import com.estelar.registry.ModItems;
import java.util.List;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class SpaceSuitItem extends ArmorItem {
	public SpaceSuitItem(Type type, Settings settings) {
		super(ModArmorMaterials.SPACE_SUIT, type, settings);
	}

	/** O traje só fornece oxigênio quando as 4 peças estão vestidas. */
	public static boolean isWearingFullSuit(LivingEntity entity) {
		return entity.getEquippedStack(EquipmentSlot.HEAD).isOf(ModItems.SPACE_HELMET)
				&& entity.getEquippedStack(EquipmentSlot.CHEST).isOf(ModItems.SPACE_CHESTPLATE)
				&& entity.getEquippedStack(EquipmentSlot.LEGS).isOf(ModItems.SPACE_LEGGINGS)
				&& entity.getEquippedStack(EquipmentSlot.FEET).isOf(ModItems.SPACE_BOOTS);
	}

	@Override
	public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
		tooltip.add(Text.translatable("tooltip.estelar.space_suit").formatted(Formatting.AQUA));
	}
}
