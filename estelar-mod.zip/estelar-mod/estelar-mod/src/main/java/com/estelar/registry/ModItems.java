package com.estelar.registry;

import com.estelar.Estelar;
import com.estelar.item.FuelCanisterItem;
import com.estelar.item.RocketItem;
import com.estelar.item.SpaceSuitItem;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

public final class ModItems {
	public static final Item RAW_TITANIUM = register("raw_titanium", new Item(new Item.Settings()));
	public static final Item TITANIUM_INGOT = register("titanium_ingot", new Item(new Item.Settings()));
	public static final Item MARS_CRYSTAL = register("mars_crystal", new Item(new Item.Settings().rarity(Rarity.UNCOMMON)));

	public static final Item FUEL_CANISTER = register("fuel_canister", new FuelCanisterItem(new Item.Settings().maxCount(16)));
	public static final Item ROCKET_ENGINE = register("rocket_engine", new Item(new Item.Settings()));

	public static final Item ROCKET_TIER_1 = register("rocket_tier_1", new RocketItem(1, new Item.Settings().maxCount(1)));
	public static final Item ROCKET_TIER_2 = register("rocket_tier_2", new RocketItem(2, new Item.Settings().maxCount(1).rarity(Rarity.UNCOMMON)));
	public static final Item ROCKET_TIER_3 = register("rocket_tier_3", new RocketItem(3, new Item.Settings().maxCount(1).rarity(Rarity.RARE)));

	public static final Item SPACE_HELMET = register("space_helmet", new SpaceSuitItem(ArmorItem.Type.HELMET,
			new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(20))));
	public static final Item SPACE_CHESTPLATE = register("space_chestplate", new SpaceSuitItem(ArmorItem.Type.CHESTPLATE,
			new Item.Settings().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(20))));
	public static final Item SPACE_LEGGINGS = register("space_leggings", new SpaceSuitItem(ArmorItem.Type.LEGGINGS,
			new Item.Settings().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(20))));
	public static final Item SPACE_BOOTS = register("space_boots", new SpaceSuitItem(ArmorItem.Type.BOOTS,
			new Item.Settings().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(20))));

	private ModItems() {
	}

	public static Item rocketForTier(int tier) {
		return switch (tier) {
			case 3 -> ROCKET_TIER_3;
			case 2 -> ROCKET_TIER_2;
			default -> ROCKET_TIER_1;
		};
	}

	private static Item register(String name, Item item) {
		return Registry.register(Registries.ITEM, Estelar.id(name), item);
	}

	public static void init() {
	}
}
