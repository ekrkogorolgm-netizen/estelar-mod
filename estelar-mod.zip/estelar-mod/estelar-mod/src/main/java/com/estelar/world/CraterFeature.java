package com.estelar.world;

import com.estelar.registry.ModBlocks;
import com.mojang.serialization.Codec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/**
 * Cava uma cratera em forma de tigela, com borda elevada.
 * Às vezes deixa um meteorito com minério no fundo.
 */
public class CraterFeature extends Feature<DefaultFeatureConfig> {
	public CraterFeature(Codec<DefaultFeatureConfig> codec) {
		super(codec);
	}

	@Override
	public boolean generate(FeatureContext<DefaultFeatureConfig> context) {
		StructureWorldAccess world = context.getWorld();
		Random random = context.getRandom();
		BlockPos origin = context.getOrigin();

		BlockState surface = world.getBlockState(origin.down());
		if (surface.isAir() || !surface.getFluidState().isEmpty()) {
			return false;
		}

		int radius = 4 + random.nextInt(9);
		double depth = radius * (0.35 + random.nextDouble() * 0.2);
		int baseY = origin.getY();
		BlockPos.Mutable pos = new BlockPos.Mutable();

		for (int dx = -radius - 2; dx <= radius + 2; dx++) {
			for (int dz = -radius - 2; dz <= radius + 2; dz++) {
				double dist = Math.sqrt(dx * dx + dz * dz);
				int x = origin.getX() + dx;
				int z = origin.getZ() + dz;
				int localTop = world.getTopY(Heightmap.Type.WORLD_SURFACE_WG, x, z);

				if (dist <= radius) {
					double t = dist / radius;
					int floorY = baseY - 1 - (int) Math.round(depth * (1.0 - t * t));
					for (int y = floorY + 1; y <= Math.max(localTop, baseY) + 2; y++) {
						pos.set(x, y, z);
						if (!world.getBlockState(pos).isAir()) {
							world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
						}
					}
					pos.set(x, floorY, z);
					if (!world.getBlockState(pos).isAir()) {
						world.setBlockState(pos, surface, Block.NOTIFY_LISTENERS);
					}
				} else if (dist <= radius + 2) {
					int rimHeight = (int) Math.round(1.6 * (1.0 - (dist - radius) / 2.0));
					for (int h = 0; h < rimHeight; h++) {
						pos.set(x, localTop + h, z);
						if (world.getBlockState(pos).isAir()) {
							world.setBlockState(pos, surface, Block.NOTIFY_LISTENERS);
						}
					}
				}
			}
		}

		// Meteorito com minério no fundo da cratera
		BlockState ore = meteorOre(surface);
		if (ore != null && random.nextInt(3) == 0) {
			int floorY = baseY - 1 - (int) Math.round(depth);
			int count = 2 + random.nextInt(4);
			for (int i = 0; i < count; i++) {
				pos.set(origin.getX() + random.nextInt(3) - 1, floorY - random.nextInt(2), origin.getZ() + random.nextInt(3) - 1);
				world.setBlockState(pos, ore, Block.NOTIFY_LISTENERS);
			}
		}
		return true;
	}

	private static BlockState meteorOre(BlockState surface) {
		if (surface.isOf(ModBlocks.MOON_REGOLITH) || surface.isOf(ModBlocks.PHOBOS_ROCK)) {
			return ModBlocks.MOON_TITANIUM_ORE.getDefaultState();
		}
		if (surface.isOf(ModBlocks.MARS_SAND)) {
			return ModBlocks.MARS_CRYSTAL_ORE.getDefaultState();
		}
		return null;
	}
}
