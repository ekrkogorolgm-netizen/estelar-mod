package com.estelar.registry;

import com.estelar.Estelar;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.math.intprovider.UniformIntProvider;

public final class ModBlocks {
	// --- Lua ---
	public static final Block MOON_REGOLITH = register("moon_regolith", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.LIGHT_GRAY).strength(0.6f).sounds(BlockSoundGroup.SAND)));
	public static final Block MOON_ROCK = register("moon_rock", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.STONE_GRAY).strength(1.5f, 6.0f).requiresTool().sounds(BlockSoundGroup.TUFF)));
	public static final Block MOON_TITANIUM_ORE = register("moon_titanium_ore", new ExperienceDroppingBlock(
			UniformIntProvider.create(1, 3), AbstractBlock.Settings.create()
			.mapColor(MapColor.STONE_GRAY).strength(3.0f, 3.0f).requiresTool().sounds(BlockSoundGroup.TUFF)));

	// --- Marte ---
	public static final Block MARS_SAND = register("mars_sand", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.ORANGE).strength(0.5f).sounds(BlockSoundGroup.SAND)));
	public static final Block MARS_ROCK = register("mars_rock", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.TERRACOTTA_RED).strength(1.5f, 6.0f).requiresTool().sounds(BlockSoundGroup.STONE)));
	public static final Block MARS_CRYSTAL_ORE = register("mars_crystal_ore", new ExperienceDroppingBlock(
			UniformIntProvider.create(3, 7), AbstractBlock.Settings.create()
			.mapColor(MapColor.TERRACOTTA_RED).strength(3.0f, 3.0f).requiresTool().luminance(state -> 7)
			.sounds(BlockSoundGroup.AMETHYST_BLOCK)));

	// --- Fobos ---
	public static final Block PHOBOS_ROCK = register("phobos_rock", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.TERRACOTTA_BROWN).strength(1.5f, 6.0f).requiresTool().sounds(BlockSoundGroup.BASALT)));

	// --- Vênus ---
	public static final Block VENUS_ROCK = register("venus_rock", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.TERRACOTTA_YELLOW).strength(1.8f, 6.0f).requiresTool().sounds(BlockSoundGroup.BASALT)));

	// --- Europa ---
	public static final Block EUROPA_ICE = register("europa_ice", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.PALE_PURPLE).strength(0.8f).slipperiness(0.98f).sounds(BlockSoundGroup.GLASS)));
	public static final Block EUROPA_ROCK = register("europa_rock", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.DEEPSLATE_GRAY).strength(2.0f, 6.0f).requiresTool().sounds(BlockSoundGroup.DEEPSLATE)));

	// --- Armazenamento ---
	public static final Block TITANIUM_BLOCK = register("titanium_block", new Block(AbstractBlock.Settings.create()
			.mapColor(MapColor.IRON_GRAY).strength(5.0f, 8.0f).requiresTool().sounds(BlockSoundGroup.METAL)));

	private ModBlocks() {
	}

	private static Block register(String name, Block block) {
		Registry.register(Registries.BLOCK, Estelar.id(name), block);
		Registry.register(Registries.ITEM, Estelar.id(name), new BlockItem(block, new Item.Settings()));
		return block;
	}

	public static void init() {
		// Carrega a classe (os campos estáticos fazem o registro).
	}
}
