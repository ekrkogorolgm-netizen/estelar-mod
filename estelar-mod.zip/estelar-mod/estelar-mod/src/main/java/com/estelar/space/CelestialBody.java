package com.estelar.space;

import com.estelar.Estelar;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Todos os lugares para onde um foguete pode ir.
 */
public enum CelestialBody {
	//      id        tier gravidade respiravel
	EARTH("earth", 1, 1.00, true),
	MOON("moon", 1, 0.17, false),
	MARS("mars", 2, 0.38, false),
	PHOBOS("phobos", 2, 0.06, false),
	VENUS("venus", 3, 0.90, false),
	EUROPA("europa", 3, 0.13, false);

	public static final int FUEL_PER_TIER_STEP = 25;

	private final String id;
	private final int tier;
	private final double gravity;
	private final boolean breathable;
	private final RegistryKey<World> worldKey;

	CelestialBody(String id, int tier, double gravity, boolean breathable) {
		this.id = id;
		this.tier = tier;
		this.gravity = gravity;
		this.breathable = breathable;
		this.worldKey = id.equals("earth") ? World.OVERWORLD : RegistryKey.of(RegistryKeys.WORLD, Estelar.id(id));
	}

	public String id() {
		return id;
	}

	/** Nível mínimo de foguete necessário para chegar aqui. */
	public int tier() {
		return tier;
	}

	public double gravity() {
		return gravity;
	}

	public boolean breathable() {
		return breathable;
	}

	public RegistryKey<World> worldKey() {
		return worldKey;
	}

	public Text displayName() {
		return Text.translatable("body.estelar." + id);
	}

	/** Combustível gasto para viajar de {@code from} até {@code to}. */
	public static int fuelCost(@Nullable CelestialBody from, CelestialBody to) {
		int fromTier = from == null ? 1 : from.tier;
		return FUEL_PER_TIER_STEP * (1 + Math.max(fromTier, to.tier));
	}

	@Nullable
	public static CelestialBody fromWorld(RegistryKey<World> key) {
		for (CelestialBody body : values()) {
			if (body.worldKey.equals(key)) {
				return body;
			}
		}
		return null;
	}

	@Nullable
	public static CelestialBody byIndex(int index) {
		CelestialBody[] values = values();
		return index >= 0 && index < values.length ? values[index] : null;
	}
}
