package com.estelar.item;

import com.estelar.entity.RocketEntity;
import com.estelar.registry.ModEntities;
import com.estelar.space.CelestialBody;
import java.util.List;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public class RocketItem extends Item {
	private final int tier;

	public RocketItem(int tier, Settings settings) {
		super(settings);
		this.tier = tier;
	}

	public int getTier() {
		return tier;
	}

	@Override
	public ActionResult useOnBlock(ItemUsageContext context) {
		World world = context.getWorld();
		if (!(world instanceof ServerWorld serverWorld)) {
			return ActionResult.SUCCESS;
		}

		BlockPos clicked = context.getBlockPos();
		BlockPos pos = context.getSide() == Direction.UP ? clicked.up() : clicked.offset(context.getSide());
		PlayerEntity player = context.getPlayer();

		RocketEntity rocket = ModEntities.ROCKET.create(serverWorld);
		if (rocket == null) {
			return ActionResult.FAIL;
		}
		float yaw = player != null ? player.getYaw() + 180.0f : 0.0f;
		rocket.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, yaw, 0.0f);
		rocket.setTier(tier);

		if (!serverWorld.isSpaceEmpty(rocket, rocket.getBoundingBox())) {
			if (player != null) {
				player.sendMessage(Text.translatable("message.estelar.no_space").formatted(Formatting.RED), true);
			}
			return ActionResult.FAIL;
		}

		serverWorld.spawnEntity(rocket);
		serverWorld.playSound(null, rocket.getX(), rocket.getY(), rocket.getZ(), SoundEvents.BLOCK_ANVIL_PLACE,
				SoundCategory.BLOCKS, 0.6f, 1.4f);
		if (player != null) {
			player.sendMessage(Text.translatable("message.estelar.rocket_placed").formatted(Formatting.YELLOW), true);
			if (!player.getAbilities().creativeMode) {
				context.getStack().decrement(1);
			}
		}
		return ActionResult.CONSUME;
	}

	@Override
	public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
		tooltip.add(Text.translatable("tooltip.estelar.rocket.tier", tier).formatted(Formatting.GOLD));
		MutableText reach = Text.translatable("tooltip.estelar.rocket.reach").formatted(Formatting.GRAY);
		boolean first = true;
		for (CelestialBody body : CelestialBody.values()) {
			if (body != CelestialBody.EARTH && body.tier() <= tier) {
				reach.append(first ? " " : ", ");
				reach.append(body.displayName().copy().formatted(Formatting.WHITE));
				first = false;
			}
		}
		tooltip.add(reach);
		tooltip.add(Text.translatable("tooltip.estelar.rocket.tank", RocketEntity.maxFuelForTier(tier)).formatted(Formatting.GRAY));
		tooltip.add(Text.translatable("tooltip.estelar.rocket.howto").formatted(Formatting.DARK_GRAY));
	}
}
