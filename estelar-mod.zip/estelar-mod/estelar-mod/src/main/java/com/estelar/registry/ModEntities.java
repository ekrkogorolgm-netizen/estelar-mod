package com.estelar.registry;

import com.estelar.Estelar;
import com.estelar.entity.RocketEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModEntities {
	public static final EntityType<RocketEntity> ROCKET = Registry.register(Registries.ENTITY_TYPE, Estelar.id("rocket"),
			EntityType.Builder.<RocketEntity>create(RocketEntity::new, SpawnGroup.MISC)
					.dimensions(1.5f, 4.5f)
					.passengerAttachments(1.4f)
					.makeFireImmune()
					.maxTrackingRange(10)
					.trackingTickInterval(1)
					.build("rocket"));

	private ModEntities() {
	}

	public static void init() {
	}
}
