package com.estelar.client;

import com.estelar.Estelar;
import com.estelar.client.render.RocketEntityRenderer;
import com.estelar.client.render.RocketModel;
import com.estelar.client.screen.NavigationScreen;
import com.estelar.client.sky.PlanetDimensionEffects;
import com.estelar.client.sky.SpaceSkyRenderer;
import com.estelar.entity.RocketEntity;
import com.estelar.registry.ModEntities;
import com.estelar.space.CelestialBody;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;

public class EstelarClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityModelLayerRegistry.registerModelLayer(RocketModel.LAYER, RocketModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.ROCKET, RocketEntityRenderer::new);

		DimensionRenderingRegistry.registerDimensionEffects(Estelar.id("space"),
				new PlanetDimensionEffects(PlanetDimensionEffects.Style.SPACE));
		DimensionRenderingRegistry.registerDimensionEffects(Estelar.id("thin_atmosphere"),
				new PlanetDimensionEffects(PlanetDimensionEffects.Style.THIN));
		DimensionRenderingRegistry.registerDimensionEffects(Estelar.id("thick_atmosphere"),
				new PlanetDimensionEffects(PlanetDimensionEffects.Style.THICK));

		// A Terra vista da Lua, Marte gigante visto de Fobos, Júpiter visto de Europa
		DimensionRenderingRegistry.registerSkyRenderer(CelestialBody.MOON.worldKey(),
				new SpaceSkyRenderer(Estelar.id("textures/environment/earth.png"), 16.0f, 20.0f, 35.0f, 10842L));
		DimensionRenderingRegistry.registerSkyRenderer(CelestialBody.PHOBOS.worldKey(),
				new SpaceSkyRenderer(Estelar.id("textures/environment/mars.png"), 60.0f, -30.0f, 25.0f, 4242L));
		DimensionRenderingRegistry.registerSkyRenderer(CelestialBody.EUROPA.worldKey(),
				new SpaceSkyRenderer(Estelar.id("textures/environment/jupiter.png"), 42.0f, 160.0f, 40.0f, 777L));

		ClientTickEvents.END_CLIENT_TICK.register(EstelarClient::onClientTick);
	}

	private static void onClientTick(MinecraftClient client) {
		boolean jumped = false;
		while (client.options.jumpKey.wasPressed()) {
			jumped = true;
		}
		if (!jumped || client.player == null || client.currentScreen != null) {
			return;
		}
		if (client.player.getVehicle() instanceof RocketEntity rocket && rocket.getPhase() == RocketEntity.PHASE_IDLE) {
			client.setScreen(new NavigationScreen(rocket));
		}
	}
}
