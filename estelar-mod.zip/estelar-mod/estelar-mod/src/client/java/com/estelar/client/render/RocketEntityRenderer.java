package com.estelar.client.render;

import com.estelar.Estelar;
import com.estelar.entity.RocketEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public class RocketEntityRenderer extends EntityRenderer<RocketEntity> {
	private static final Identifier[] TEXTURES = {
			Estelar.id("textures/entity/rocket_tier_1.png"),
			Estelar.id("textures/entity/rocket_tier_2.png"),
			Estelar.id("textures/entity/rocket_tier_3.png"),
	};

	private final ModelPart model;

	public RocketEntityRenderer(EntityRendererFactory.Context context) {
		super(context);
		this.model = context.getPart(RocketModel.LAYER);
		this.shadowRadius = 0.8f;
	}

	@Override
	public void render(RocketEntity entity, float yaw, float tickDelta, MatrixStack matrices,
			VertexConsumerProvider vertexConsumers, int light) {
		matrices.push();
		matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - yaw));

		// Tremedeira dos motores na contagem e na subida
		int phase = entity.getPhase();
		if (phase == RocketEntity.PHASE_COUNTDOWN || phase == RocketEntity.PHASE_ASCENT) {
			float time = entity.age + tickDelta;
			float strength = phase == RocketEntity.PHASE_ASCENT ? 0.035f : 0.015f;
			matrices.translate(MathHelper.sin(time * 2.7f) * strength, 0.0, MathHelper.cos(time * 3.1f) * strength);
		}

		matrices.scale(-1.0f, -1.0f, 1.0f);
		VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntityCutout(getTexture(entity)));
		this.model.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV);
		matrices.pop();

		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}

	@Override
	public Identifier getTexture(RocketEntity entity) {
		return TEXTURES[MathHelper.clamp(entity.getTier(), 1, 3) - 1];
	}
}
