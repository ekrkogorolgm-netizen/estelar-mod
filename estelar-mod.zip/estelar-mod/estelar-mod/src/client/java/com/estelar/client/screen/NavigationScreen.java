package com.estelar.client.screen;

import com.estelar.Estelar;
import com.estelar.entity.RocketEntity;
import com.estelar.network.LaunchPayload;
import com.estelar.space.CelestialBody;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.Entity;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

/**
 * Painel de navegação: escolha para onde o foguete vai.
 */
public class NavigationScreen extends Screen {
	private static final int BUTTON_WIDTH = 150;
	private static final int BUTTON_HEIGHT = 20;
	private static final int ICON_SIZE = 20;

	private final int rocketId;

	public NavigationScreen(RocketEntity rocket) {
		super(Text.translatable("screen.estelar.navigation"));
		this.rocketId = rocket.getId();
	}

	@Nullable
	private RocketEntity rocket() {
		if (this.client == null || this.client.world == null) {
			return null;
		}
		Entity entity = this.client.world.getEntityById(this.rocketId);
		return entity instanceof RocketEntity rocket ? rocket : null;
	}

	@Nullable
	private CelestialBody currentBody() {
		return this.client == null || this.client.world == null ? null
				: CelestialBody.fromWorld(this.client.world.getRegistryKey());
	}

	private int gridLeft() {
		return this.width / 2 - BUTTON_WIDTH - 10 - ICON_SIZE / 2;
	}

	private int gridTop() {
		return this.height / 2 - 45;
	}

	@Override
	protected void init() {
		RocketEntity rocket = rocket();
		if (rocket == null) {
			close();
			return;
		}
		CelestialBody here = currentBody();
		CelestialBody[] bodies = CelestialBody.values();

		for (int i = 0; i < bodies.length; i++) {
			CelestialBody body = bodies[i];
			int column = i % 2;
			int row = i / 2;
			int x = gridLeft() + ICON_SIZE + 4 + column * (BUTTON_WIDTH + ICON_SIZE + 12);
			int y = gridTop() + row * (BUTTON_HEIGHT + 8);

			int cost = CelestialBody.fuelCost(here, body);
			boolean isHere = body == here;
			boolean tierOk = body.tier() <= rocket.getTier() && (here == null || here.tier() <= rocket.getTier());
			boolean fuelOk = rocket.getFuel() >= cost;

			MutableText label = body.displayName().copy();
			if (isHere) {
				label.append(Text.translatable("screen.estelar.here")).formatted(Formatting.GRAY);
			}

			MutableText info = Text.empty()
					.append(body.displayName().copy().formatted(Formatting.AQUA, Formatting.BOLD)).append("\n")
					.append(Text.translatable("screen.estelar.info.gravity", String.format("%.2f", body.gravity()))).append("\n")
					.append(Text.translatable(body.breathable() ? "screen.estelar.info.air_yes" : "screen.estelar.info.air_no")).append("\n")
					.append(Text.translatable("screen.estelar.info.tier", body.tier())).append("\n")
					.append(Text.translatable("screen.estelar.info.cost", cost));
			if (!tierOk) {
				info.append("\n").append(Text.translatable("screen.estelar.info.need_tier", Math.max(body.tier(), here == null ? 1 : here.tier())).formatted(Formatting.RED));
			} else if (!fuelOk && !isHere) {
				info.append("\n").append(Text.translatable("screen.estelar.info.need_fuel").formatted(Formatting.RED));
			}

			ButtonWidget button = ButtonWidget.builder(label, b -> launch(body))
					.dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
					.tooltip(Tooltip.of(info))
					.build();
			button.active = !isHere && tierOk && fuelOk;
			addDrawableChild(button);
		}

		addDrawableChild(ButtonWidget.builder(ScreenTexts.CANCEL, b -> close())
				.dimensions(this.width / 2 - 50, gridTop() + 3 * (BUTTON_HEIGHT + 8) + 30, 100, BUTTON_HEIGHT)
				.build());
	}

	private void launch(CelestialBody body) {
		ClientPlayNetworking.send(new LaunchPayload(body.ordinal()));
		close();
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		RocketEntity rocket = rocket();
		if (rocket == null) {
			return;
		}

		int centerX = this.width / 2;
		context.drawCenteredTextWithShadow(this.textRenderer, this.title.copy().formatted(Formatting.BOLD), centerX, gridTop() - 52, 0xFFFFFF);

		CelestialBody here = currentBody();
		Text location = here != null ? here.displayName() : Text.translatable("screen.estelar.unknown_place");
		context.drawCenteredTextWithShadow(this.textRenderer,
				Text.translatable("screen.estelar.location", location, rocket.getTier()), centerX, gridTop() - 38, 0xA0E0FF);

		// Barra de combustível
		int barWidth = 200;
		int barX = centerX - barWidth / 2;
		int barY = gridTop() - 24;
		float ratio = rocket.getMaxFuel() == 0 ? 0 : (float) rocket.getFuel() / rocket.getMaxFuel();
		context.fill(barX - 1, barY - 1, barX + barWidth + 1, barY + 9, 0xFF000000);
		context.fill(barX, barY, barX + barWidth, barY + 8, 0xFF3A2A10);
		context.fill(barX, barY, barX + (int) (barWidth * ratio), barY + 8, 0xFFFF9A1F);
		context.drawCenteredTextWithShadow(this.textRenderer,
				Text.translatable("screen.estelar.fuel", rocket.getFuel(), rocket.getMaxFuel()), centerX, barY, 0xFFFFFF);

		// Ícones dos planetas ao lado dos botões
		CelestialBody[] bodies = CelestialBody.values();
		for (int i = 0; i < bodies.length; i++) {
			int column = i % 2;
			int row = i / 2;
			int x = gridLeft() + column * (BUTTON_WIDTH + ICON_SIZE + 12);
			int y = gridTop() + row * (BUTTON_HEIGHT + 8);
			Identifier icon = Estelar.id("textures/environment/" + bodies[i].id() + ".png");
			context.drawTexture(icon, x, y, ICON_SIZE, ICON_SIZE, 0.0f, 0.0f, 64, 64, 64, 64);
		}

		context.drawCenteredTextWithShadow(this.textRenderer, Text.translatable("screen.estelar.hint"),
				centerX, gridTop() + 3 * (BUTTON_HEIGHT + 8) + 12, 0x909090);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
