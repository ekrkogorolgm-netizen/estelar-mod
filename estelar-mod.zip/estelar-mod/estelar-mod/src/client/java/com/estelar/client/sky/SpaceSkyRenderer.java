package com.estelar.client.sky;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Random;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Céu de um lugar sem atmosfera: preto, cheio de estrelas, com o Sol
 * e um planeta grande parado no céu (a Terra vista da Lua, por exemplo).
 */
public class SpaceSkyRenderer implements DimensionRenderingRegistry.SkyRenderer {
	private static final Identifier SUN = Identifier.ofVanilla("textures/environment/sun.png");
	private static final int STAR_COUNT = 2200;

	private final Identifier planetTexture;
	private final float planetSize;
	private final float planetYaw;
	private final float planetTilt;
	private final float[] stars; // x, y, z por vértice
	private final float[] starColors; // r, g, b, a por estrela

	public SpaceSkyRenderer(Identifier planetTexture, float planetSize, float planetYaw, float planetTilt, long seed) {
		this.planetTexture = planetTexture;
		this.planetSize = planetSize;
		this.planetYaw = planetYaw;
		this.planetTilt = planetTilt;
		this.stars = new float[STAR_COUNT * 4 * 3];
		this.starColors = new float[STAR_COUNT * 4];
		buildStars(seed);
	}

	private void buildStars(long seed) {
		Random random = new Random(seed);
		int i = 0;
		while (i < STAR_COUNT) {
			float x = random.nextFloat() * 2.0f - 1.0f;
			float y = random.nextFloat() * 2.0f - 1.0f;
			float z = random.nextFloat() * 2.0f - 1.0f;
			float lengthSq = x * x + y * y + z * z;
			if (lengthSq < 0.01f || lengthSq > 1.0f) {
				continue;
			}
			Vector3f dir = new Vector3f(x, y, z).normalize();
			Vector3f center = new Vector3f(dir).mul(100.0f);
			Vector3f helper = Math.abs(dir.y) < 0.9f ? new Vector3f(0, 1, 0) : new Vector3f(1, 0, 0);
			Vector3f u = new Vector3f(dir).cross(helper).normalize();
			Vector3f v = new Vector3f(dir).cross(u).normalize();

			float size = 0.12f + random.nextFloat() * 0.22f;
			if (random.nextInt(40) == 0) {
				size *= 2.0f; // algumas estrelas bem brilhantes
			}
			u.mul(size);
			v.mul(size);

			int base = i * 12;
			put(base, center.x - u.x - v.x, center.y - u.y - v.y, center.z - u.z - v.z);
			put(base + 3, center.x + u.x - v.x, center.y + u.y - v.y, center.z + u.z - v.z);
			put(base + 6, center.x + u.x + v.x, center.y + u.y + v.y, center.z + u.z + v.z);
			put(base + 9, center.x - u.x + v.x, center.y - u.y + v.y, center.z - u.z + v.z);

			float tint = random.nextFloat();
			float r = 1.0f;
			float g = 1.0f;
			float b = 1.0f;
			if (tint < 0.15f) {
				r = 0.75f;
				g = 0.85f; // azuladas
			} else if (tint < 0.3f) {
				b = 0.7f;
				g = 0.9f; // amareladas
			}
			int c = i * 4;
			starColors[c] = r;
			starColors[c + 1] = g;
			starColors[c + 2] = b;
			starColors[c + 3] = 0.55f + random.nextFloat() * 0.45f;
			i++;
		}
	}

	private void put(int index, float x, float y, float z) {
		stars[index] = x;
		stars[index + 1] = y;
		stars[index + 2] = z;
	}

	@Override
	public void render(WorldRenderContext context) {
		ClientWorld world = context.world();
		if (world == null) {
			return;
		}
		float tickDelta = context.tickCounter().getTickDelta(false);

		MatrixStack matrices = new MatrixStack();
		matrices.multiplyPositionMatrix(context.positionMatrix());

		BackgroundRenderer.clearFog();
		RenderSystem.depthMask(false);
		RenderSystem.disableCull();
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

		// Estrelas e Sol giram com o dia
		matrices.push();
		matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90.0f));
		matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(world.getSkyAngle(tickDelta) * 360.0f));
		Matrix4f skyMatrix = matrices.peek().getPositionMatrix();
		drawStars(skyMatrix);
		drawSun(skyMatrix);
		matrices.pop();

		// Planeta fixo no céu (os corpos estão em rotação sincronizada)
		matrices.push();
		matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(this.planetYaw));
		matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(this.planetTilt));
		drawPlanet(matrices.peek().getPositionMatrix());
		matrices.pop();

		RenderSystem.defaultBlendFunc();
		RenderSystem.disableBlend();
		RenderSystem.enableCull();
		RenderSystem.depthMask(true);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	}

	private void drawStars(Matrix4f matrix) {
		RenderSystem.setShader(GameRenderer::getPositionColorProgram);
		RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE,
				GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ZERO);
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
		for (int star = 0; star < STAR_COUNT; star++) {
			int c = star * 4;
			float r = starColors[c];
			float g = starColors[c + 1];
			float b = starColors[c + 2];
			float a = starColors[c + 3];
			for (int corner = 0; corner < 4; corner++) {
				int p = star * 12 + corner * 3;
				buffer.vertex(matrix, stars[p], stars[p + 1], stars[p + 2]).color(r, g, b, a);
			}
		}
		draw(buffer);
	}

	private void drawSun(Matrix4f matrix) {
		RenderSystem.setShader(GameRenderer::getPositionTexProgram);
		RenderSystem.setShaderTexture(0, SUN);
		RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE,
				GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ZERO);
		float k = 26.0f;
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);
		buffer.vertex(matrix, -k, 100.0f, -k).texture(0.0f, 0.0f);
		buffer.vertex(matrix, k, 100.0f, -k).texture(1.0f, 0.0f);
		buffer.vertex(matrix, k, 100.0f, k).texture(1.0f, 1.0f);
		buffer.vertex(matrix, -k, 100.0f, k).texture(0.0f, 1.0f);
		draw(buffer);
	}

	private void drawPlanet(Matrix4f matrix) {
		RenderSystem.setShader(GameRenderer::getPositionTexProgram);
		RenderSystem.setShaderTexture(0, this.planetTexture);
		RenderSystem.defaultBlendFunc();
		float k = this.planetSize;
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);
		buffer.vertex(matrix, -k, 100.0f, -k).texture(0.0f, 0.0f);
		buffer.vertex(matrix, k, 100.0f, -k).texture(1.0f, 0.0f);
		buffer.vertex(matrix, k, 100.0f, k).texture(1.0f, 1.0f);
		buffer.vertex(matrix, -k, 100.0f, k).texture(0.0f, 1.0f);
		draw(buffer);
	}

	private static void draw(BufferBuilder buffer) {
		BuiltBuffer built = buffer.endNullable();
		if (built != null) {
			BufferRenderer.drawWithGlobalProgram(built);
		}
	}
}
