package com.estelar.client.render;

import com.estelar.Estelar;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;

/**
 * Geometria do foguete. Os valores de UV casam com a textura gerada por tools/rocket_parts.py.
 */
public final class RocketModel {
	public static final EntityModelLayer LAYER = new EntityModelLayer(Estelar.id("rocket"), "main");

	private RocketModel() {
	}

	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData root = modelData.getRoot();

		add(root, "body_a", 0, 0, -6, -52, -8, 12, 44, 16);
		add(root, "body_b", 56, 0, -8, -51, -6, 16, 42, 12);
		add(root, "nozzle_low", 0, 88, -6, -4, -6, 12, 4, 12);
		add(root, "nozzle_high", 80, 88, -4, -8, -4, 8, 4, 8);
		add(root, "nose1", 48, 60, -6, -60, -6, 12, 8, 12);
		add(root, "nose2", 48, 88, -4, -66, -4, 8, 6, 8);
		add(root, "nose3", 112, 88, -2, -70, -2, 4, 4, 4);
		add(root, "tip", 14, 104, -1, -73, -1, 2, 3, 2);
		add(root, "fin_east", 16, 60, 8, -22, -1, 6, 22, 2);
		add(root, "fin_west", 32, 60, -14, -22, -1, 6, 22, 2);
		add(root, "fin_south", 112, 0, -1, -22, 8, 2, 22, 6);
		add(root, "fin_north", 0, 60, -1, -22, -14, 2, 22, 6);
		add(root, "window", 0, 104, -3, -46, -9, 6, 6, 1);

		return TexturedModelData.of(modelData, 128, 128);
	}

	private static void add(ModelPartData root, String name, int u, int v,
			float x, float y, float z, float w, float h, float d) {
		root.addChild(name, ModelPartBuilder.create().uv(u, v).cuboid(x, y, z, w, h, d), ModelTransform.NONE);
	}
}
