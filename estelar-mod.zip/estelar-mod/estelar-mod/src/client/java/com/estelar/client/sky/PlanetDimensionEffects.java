package com.estelar.client.sky;

import net.minecraft.client.render.DimensionEffects;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

/**
 * Efeitos visuais das dimensões do mod: sem nuvens, sem o laranja do pôr do sol
 * no espaço e, em Vênus, uma névoa grossa.
 */
public class PlanetDimensionEffects extends DimensionEffects {
	public enum Style {
		/** Sem atmosfera: Lua, Fobos, Europa. */
		SPACE,
		/** Atmosfera fina: Marte. */
		THIN,
		/** Atmosfera densa e tóxica: Vênus. */
		THICK
	}

	private final Style style;

	public PlanetDimensionEffects(Style style) {
		super(Float.NaN, style != Style.SPACE, SkyType.NORMAL, false, false);
		this.style = style;
	}

	@Override
	public Vec3d adjustFogColor(Vec3d color, float sunHeight) {
		if (this.style == Style.SPACE) {
			return color;
		}
		float light = Math.max(sunHeight, 0.0f) * 0.94f + 0.06f;
		return color.multiply(light, light, light);
	}

	@Override
	public boolean useThickFog(int camX, int camY) {
		return this.style == Style.THICK;
	}

	@Override
	@Nullable
	public float[] getFogColorOverride(float skyAngle, float tickDelta) {
		return this.style == Style.SPACE ? null : super.getFogColorOverride(skyAngle, tickDelta);
	}
}
